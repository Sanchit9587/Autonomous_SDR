"""
Seeds two demo campaigns that tell the same story as the ICP validation
work: the SAME real person (Shalu Chadha) is correctly excluded by one
campaign's ICP and correctly included by another - proving the filter is
doing its job, not failing.

Run this AFTER starting the API server:
    uvicorn app.main:app --reload --port 8000
    python scripts/seed_demo.py
"""
import os
import requests

BASE = os.getenv("API_BASE_URL", "http://localhost:8000")


def create_campaign(payload):
    r = requests.post(f"{BASE}/campaigns", json=payload, timeout=30)
    r.raise_for_status()
    return r.json()


def find_leads(campaign_id):
    r = requests.post(f"{BASE}/campaigns/{campaign_id}/find-leads", timeout=60)
    r.raise_for_status()
    return r.json()


def main():
    campaign_a = create_campaign({
        "name": "BFSI Tech Leaders - India",
        "description": "Strict current-role ICP: active CIO/CDO/CTO at a BFSI company, based in India.",
        "icp_filter": {
            "role_titles": ["CIO", "CDO", "CTO", "Chief Information Officer", "Chief Digital Officer", "Chief Technology Officer"],
            "seniority": ["c_suite"],
            "min_years_experience": 15,
            "industry_tags": ["Banking", "Financial Services", "Insurance"],
            "person_location": ["India"],
            "company_location": [],
            "title_match_mode": "current_only",
            "signal_tags": [],
            "reference_profiles": [],
        },
        "scoring_weights": {},
        "enabled_channels": ["email", "linkedin"],
    })
    print(f"Created campaign A: {campaign_a['id']} - {campaign_a['name']}")

    campaign_b = create_campaign({
        "name": "Ex-BFSI Leaders & Advisors - India",
        "description": (
            "Wider ICP: people who HELD a BFSI CIO/CDO/CTO-level role in the last 5 years, "
            "even if their current title/employer has moved on - a different, valid segment "
            "(advisors, board members, VP-level BFSI-adjacent leaders)."
        ),
        "icp_filter": {
            "role_titles": ["CIO", "CDO", "CTO", "Chief Information Officer", "Chief Digital Officer", "Chief Technology Officer"],
            "seniority": ["c_suite", "vp"],
            "min_years_experience": 15,
            "industry_tags": ["Banking", "Financial Services", "Insurance"],
            "person_location": ["India"],
            "company_location": [],
            "title_match_mode": "current_or_historical",
            "historical_lookback_years": 5,
            "signal_tags": ["advising bfsi", "advisor", "board member"],
            "reference_profiles": [
                "Former BFSI Chief Information Officer now advising financial services companies on AI and data strategy",
            ],
        },
        "scoring_weights": {},
        "enabled_channels": ["email", "linkedin"],
    })
    print(f"Created campaign B: {campaign_b['id']} - {campaign_b['name']}")

    print("\nRunning find-leads on campaign A (strict, current-only)...")
    results_a = find_leads(campaign_a["id"])
    shalu_a = next((r for r in results_a if r["lead"]["full_name"] == "Shalu Chadha"), None)
    print(f"  {len(results_a)} leads scored.")
    if shalu_a:
        print(f"  Shalu Chadha -> score={shalu_a['score']}, stage={shalu_a['stage']}")
        print(f"  Explanation: {shalu_a['explanation']}")

    print("\nRunning find-leads on campaign B (current-or-historical + signal tags)...")
    results_b = find_leads(campaign_b["id"])
    shalu_b = next((r for r in results_b if r["lead"]["full_name"] == "Shalu Chadha"), None)
    print(f"  {len(results_b)} leads scored.")
    if shalu_b:
        print(f"  Shalu Chadha -> score={shalu_b['score']}, stage={shalu_b['stage']}")
        print(f"  Explanation: {shalu_b['explanation']}")

    print("\nDone. Open the Streamlit control panel to browse both campaigns:")
    print("  streamlit run control_panel.py")


if __name__ == "__main__":
    main()
