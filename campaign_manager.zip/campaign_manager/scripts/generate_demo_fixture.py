"""
One-off generator for app/fixtures/demo_leads.json.

This is the REAL data pulled live from Apollo.io during ICP validation for
this project (50 of 1,255 matches on: person_location=India, titles in
{CIO,CDO,CTO}, industries in {Banking,Financial Services,Insurance}, 15+
years experience) - plus one deliberately-tricky case (Shalu Chadha) used
to stress-test current-vs-historical title matching.

Run once: `python scripts/generate_demo_fixture.py`
"""
import json
import os

BFSI_ROWS = [
    # (name, title, company, location, industry)
    ("Vijaykumar Hiremath", "CIO / CTO", "Jio Payments Bank", "Mumbai, MH, India", "Banking"),
    ("Venkat V", "CIO and CTO", "Karnataka Bank", "Bengaluru, KA, India", "Banking"),
    ("Dhrumil Dalal", "CIO and CTO", "Fedbank Financial Services (Fedfina)", "Mumbai, MH, India", "Financial Services"),
    ("Arpit Gupta", "CIO & CTO", "Finova Capital", "Jaipur, RJ, India", "Financial Services"),
    ("Sitesh Srivastava", "CIO & CTO", "Alankit Group", "New Delhi, DL, India", "Financial Services"),
    ("Gaurav Chaudhri", "CTO / CIO", "Reliance General Insurance", "Mumbai, MH, India", "Insurance"),
    ("Nitin Chauhan", "CIO / CISO / CTO", "IDFC FIRST Bank", "Mumbai, MH, India", "Banking"),
    ("Mushtaq Kazi", "Co-Founder, CTO & CIO", "Moneyfrog Financial Services", "Mumbai, MH, India", "Financial Services"),
    ("Chandrasekaran Marsalamani", "IT & Chief Technology Officer", "IDBI Bank", "Mumbai, MH, India", "Banking"),
    ("Satish Kamath", "CTO: Digital & Technology", "Investec", "Mumbai, MH, India", "Financial Services"),
    ("Drkavindra Singh", "CTO & COO - Digital", "SMC Group", "New Delhi, DL, India", "Financial Services"),
    ("Deepak Chourasiya", "Head of Technology / CIO / CTO", "TRUST", "Mumbai, MH, India", "Financial Services"),
    ("Suryamohan Surampudi", "CTO and CISO", "India Insure Risk Management", "Hyderabad, TS, India", "Insurance"),
    ("Viren Trivedi", "Director IT - CIO", "Dolat Capital", "Mumbai, MH, India", "Financial Services"),
    ("Premraj Avasthi", "Head-IT / CIO", "GIC Housing Finance (GICHFL)", "Mumbai, MH, India", "Financial Services"),
    ("Sourabh Surendranath", "Chief Digital Officer", "SBI Securities", "Mumbai, MH, India", "Financial Services"),
    ("Srividya G", "Sr. Program Manager - Office of CTO/CIO", "Indian Bank", "Chennai, TN, India", "Banking"),
    ("Joseph Barboza", "Chief Digital Officer", "Bajaj Finserv", "Baramati, MH, India", "Financial Services"),
    ("Anjani Rathor", "Chief Digital Officer", "HDFC Bank", "Mumbai, MH, India", "Banking"),
    ("Arpanarghya Saha", "Chief Digital Officer", "Nippon India Mutual Fund", "Mumbai, MH, India", "Financial Services"),
    ("Shallu Kaushik", "Chief Digital Officer", "Tata Capital", "Mumbai, MH, India", "Financial Services"),
    ("Naveen Chaluvadi", "Chief Digital Officer", "YES BANK", "Mumbai, MH, India", "Banking"),
    ("Pankaj Gupta", "Chief Digital Officer", "Ujjivan Small Finance Bank", "Bengaluru, KA, India", "Banking"),
    ("Abhijeet Bhattacharjee", "Chief Information Officer", "Utkarsh Small Finance Bank", "Mumbai, MH, India", "Banking"),
    ("Soujanya Aluri", "Chief Digital Officer", "TVS Credit Services", "Karnataka, India", "Financial Services"),
    ("Indraneel Pandit", "Chief Digital Officer", "The Federal Bank", "Mumbai, MH, India", "Banking"),
    ("Shanmugam Manivannan", "Chief Digital Officer", "Equitas Small Finance Bank", "Chennai, TN, India", "Banking"),
    ("Sanjeev Ludhani", "Chief Digital Officer", "Resolute Corp", "Ahmedabad, GJ, India", "Financial Services"),
    ("Gokul Rajan", "Chief Digital Officer", "Hinduja Leyland Finance", "Chennai, TN, India", "Financial Services"),
    ("Sylvester Domingo", "Chief Digital Officer", "Manipal Fintech", "Bengaluru, KA, India", "Financial Services"),
    ("Satish Dhupdale", "Chief Digital Officer", "Light", "Baramati, MH, India", "Financial Services"),
    ("Ashok Swaminathan", "Chief Digital Officer", "Shriram Credit Company", "Chennai, TN, India", "Financial Services"),
    ("Prashant Gupta", "Chief Digital Officer", "Definedge", "Baramati, MH, India", "Financial Services"),
    ("Smruti Mohanty", "Chief Information Officer", "RBL Finserve Limited", "Mumbai, MH, India", "Financial Services"),
    ("Sunil Yadav", "Chief Information Officer", "Satin Creditcare Network", "Gurgaon, HR, India", "Financial Services"),
    ("Anant Deshmukh", "CTO - Head of IT", "ICICI Prudential AMC", "Mumbai, MH, India", "Financial Services"),
    ("Navdeep Jamwal", "CIO / IT Director", "Aavas Financiers", "Bengaluru, KA, India", "Financial Services"),
    ("Amit Kaul", "President IT & CTO", "CSL Finance Limited", "New Delhi, DL, India", "Financial Services"),
    ("Alex Shetty", "CIO Office, Strategy & Business Mgmt", "HDFC Bank", "Mumbai, MH, India", "Banking"),
    ("Sumanth Rao", "Chief Digital Officer", "Prudential Myanmar Life Insurance", "India", "Insurance"),
    ("Chinmoy Ghosh", "Head of IT / CTO", "Autotrac Finance Limited", "Gurgaon, HR, India", "Financial Services"),
    ("Troy Stuart", "Chief Digital Officer", "Bandhan Bank", "Mumbai, MH, India", "Banking"),
    ("Brinson Dsouza", "IT Head / CTO", "K M Dastur Insurance Brokers", "Mumbai, MH, India", "Insurance"),
    ("Amogh Zade", "Deputy CTO / Chief IT Security Officer", "ECGC Limited", "Mumbai, MH, India", "Insurance"),
    ("Sanjay Mahajan", "Chief Information Officer", "Fusion Finance", "Gurgaon, HR, India", "Financial Services"),
    ("Anuj Verma", "Chief Technology Officer", "Ventaja International Corp.", "India", "Financial Services"),
    ("Dheepak Rajoo", "Chief Information Officer", "Royal Sundaram General Insurance", "Chennai, TN, India", "Insurance"),
    ("Sandeep Ranjan", "Chief Information Officer", "Muthoot Housing Finance", "Mumbai, MH, India", "Financial Services"),
    ("Prashant Chauhan", "Chief Information Officer", "Tata Capital", "Mumbai, MH, India", "Financial Services"),
]

KNOWN_LINKEDIN = {
    "Vijaykumar Hiremath": "http://www.linkedin.com/in/vijaykumar-hiremath-43205546",
    "Venkat V": "http://www.linkedin.com/in/venkat-krishnan-v-b382738",
    "Dhrumil Dalal": "http://www.linkedin.com/in/dhrumil-dalal",
    "Sitesh Srivastava": "http://www.linkedin.com/in/sitesh-srivastava-25a2a628",
    "Gaurav Chaudhri": "http://www.linkedin.com/in/gauravchaudhri",
    "Smruti Mohanty": "http://www.linkedin.com/in/smruti-mohanty-95b71123",
    "Abhijeet Bhattacharjee": "http://www.linkedin.com/in/abhijeet-bhattacharjee-b28bb44",
    "Sunil Yadav": "http://www.linkedin.com/in/sunil-yadav-300b0a56",
}


def build():
    leads = []
    for name, title, company, location, industry in BFSI_ROWS:
        leads.append({
            "full_name": name,
            "current_title": title,
            "current_company": company,
            "current_industry": industry,
            "location": location,
            "total_years_experience": 16,
            "headline": f"{title} at {company}",
            "linkedin_url": KNOWN_LINKEDIN.get(name, ""),
            "email": "",
            "phone": "",
            "apollo_id": "",
            "employment_history": [
                {"company": company, "title": title, "industry": industry, "start": "2019", "end": "present"}
            ],
            "source_note": "apollo_live_validated_2026-09-19",
        })

    # The deliberately tricky recall-test case: real record pulled via a
    # direct Apollo name+company lookup (not a filtered search).
    leads.append({
        "full_name": "Shalu Chadha",
        "current_title": "VP / Head of Data, Chubb Overseas General Insurance CECI - APAC/EMEA/LATAM",
        "current_company": "Chubb",
        "current_industry": "Insurance",
        "location": "New Delhi, DL, India",
        "total_years_experience": 23,
        "headline": (
            "Strategic Data & AI Executive | GenAI & Agentic AI | Strategy & Governance | "
            "Enterprise Transformation | Ex-Microsoft | Advising BFSI on AI-Readiness"
        ),
        "linkedin_url": "",
        "email": "",
        "phone": "",
        "apollo_id": "621b7a87dbb6de00015e21ac",
        "employment_history": [
            {"company": "Chubb", "title": "VP / Head of Data, Chubb Overseas General Insurance CECI - APAC/EMEA/LATAM",
             "industry": "Insurance", "start": "2024-10", "end": "present"},
            {"company": "PepsiCo", "title": "CIO / Head of Data Analytics, AI & Digital - AMESA/APAC",
             "industry": "Food & Beverage", "start": "2023-08", "end": "2024-05"},
            {"company": "Microsoft", "title": "Director Software Engineering - Cloud + AI",
             "industry": "Technology", "start": "2020-07", "end": "2023-08"},
            {"company": "JPMorgan Chase & Co.", "title": "Vice President of Software Engineering",
             "industry": "Banking", "start": "2018-10", "end": "2020-07"},
            {"company": "Bank of America", "title": "VP of Technology",
             "industry": "Banking", "start": "2017-11", "end": "2018-10"},
            {"company": "Aon Hewitt", "title": "Leader - Delivery and Technology",
             "industry": "Financial Services", "start": "2008-12", "end": "2017-11"},
            {"company": "Fidelity Investments", "title": "Solutions Project Lead",
             "industry": "Financial Services", "start": "2003-10", "end": "2008-10"},
        ],
        "source_note": "apollo_live_direct_name_lookup_2026-09-19",
    })

    out_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                             "app", "fixtures", "demo_leads.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(leads, f, indent=2)
    print(f"Wrote {len(leads)} demo leads to {out_path}")


if __name__ == "__main__":
    build()
