"""
Turns a ScoreResult into a human-readable explanation.

Always grounded in the structured breakdown - never free-form guessing.
If ANTHROPIC_API_KEY is set, we ask Claude to phrase the same facts more
naturally (still fed ONLY the structured signals, so it cannot hallucinate
a reason that isn't in the breakdown). Otherwise a deterministic template
does the job, so the app never depends on having an LLM key to explain
itself - a big part of the "no hallucination" requirement in the brief.
"""
from app.config import settings
from app.models import Lead
from app.scoring import ScoreResult

_LABELS = {
    "current_title_exact": "current title exactly matches a target role",
    "historical_title_within_lookback": "held a target role within the lookback window",
    "seniority_match": "seniority tier matches",
    "yoe_meets_floor": "meets the minimum years-of-experience bar",
    "industry_match": "industry matches (current or historical employer)",
    "signal_tag_match": "bio/headline matches a target signal keyword",
    "reference_profile_similarity": "profile is textually similar to a known-good reference example",
}


def template_explanation(lead: Lead, result: ScoreResult) -> str:
    if not result.location_gate_passed:
        return (
            f"Rejected: {lead.full_name} does not satisfy the person-location requirement "
            f"(hard gate) - lead location is '{lead.location or 'unknown'}'."
        )
    if result.breakdown.get("excluded"):
        return f"Rejected: {lead.full_name} matches an exclusion rule for this campaign."

    hits = [f"{_LABELS.get(k, k)} (+{v})" for k, v in result.breakdown.items()
            if isinstance(v, (int, float)) and not k.startswith("_")]
    if not hits:
        return (
            f"Rejected: {lead.full_name} (current title '{lead.current_title}') matched none of "
            f"the configured signals for this campaign's ICP."
        )
    via = "current role" if result.matched_via == "current" else (
        "past role" if result.matched_via == "historical" else "no title match")
    verdict = {"qualified": "Auto-qualified", "in_review": "Sent to human review", "rejected": "Rejected"}[result.stage]
    return (
        f"{verdict} ({result.score:.0f}/100) - {lead.full_name}, {lead.current_title} at "
        f"{lead.current_company}. Matched on: {', '.join(hits)}. Title match came from: {via}."
    )


def explain(lead: Lead, result: ScoreResult) -> str:
    fallback = template_explanation(lead, result)
    if not settings.anthropic_api_key:
        return fallback
    try:
        import anthropic  # optional dependency, only imported if a key is set
        client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
        facts = {
            "name": lead.full_name,
            "current_title": lead.current_title,
            "current_company": lead.current_company,
            "score": result.score,
            "stage": result.stage,
            "matched_signals": {k: v for k, v in result.breakdown.items() if not k.startswith("_")},
            "matched_via": result.matched_via,
            "location_gate_passed": result.location_gate_passed,
        }
        msg = client.messages.create(
            model="claude-sonnet-5",
            max_tokens=120,
            messages=[{
                "role": "user",
                "content": (
                    "You are writing a one-sentence, factual explanation of why a sales lead "
                    "was scored this way. Use ONLY the facts given below - do not add, infer, "
                    "or embellish anything not present in this JSON. If a field is empty, don't "
                    f"mention it.\n\nFacts: {facts}"
                ),
            }],
        )
        text = "".join(block.text for block in msg.content if hasattr(block, "text")).strip()
        return text or fallback
    except Exception:
        # Any API/network/key issue -> never break scoring over an explanation.
        return fallback
