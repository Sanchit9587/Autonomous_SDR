"""
Common channel adapter interface.

Every channel (email, sms, voice, linkedin) implements `send(lead, subject,
content) -> (status, provider, provider_ref, meta)`. This is exactly the
shape a DronaHQ agent's "Code" or "Connector" tool would call into if this
backend is exposed behind the FastAPI routes in app/main.py - the agent
decides WHEN and WHAT to send (personalization, sequencing, replies), this
adapter only handles the HOW of actually delivering it and logging the
result.

All channels respect DRY_RUN (default true): with no provider creds
configured, every send is safely logged as an intended action instead of
actually going out, so the whole pipeline is demoable end-to-end with zero
external accounts.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass

from app.config import settings
from app.models import Lead


@dataclass
class SendResult:
    status: str            # "sent" | "dry_run" | "failed"
    provider: str
    provider_ref: str = ""
    meta: dict = None

    def __post_init__(self):
        if self.meta is None:
            self.meta = {}


class ChannelAdapter(ABC):
    name: str = "base"

    @abstractmethod
    def send(self, lead: Lead, subject: str, content: str) -> SendResult:
        ...


def get_channel_adapter(channel: str) -> ChannelAdapter:
    from app.channels.email_channel import EmailAdapter
    from app.channels.sms_channel import SMSAdapter
    from app.channels.voice_channel import VoiceAdapter
    from app.channels.linkedin_channel import LinkedInAdapter

    registry = {
        "email": EmailAdapter,
        "sms": SMSAdapter,
        "voice": VoiceAdapter,
        "linkedin": LinkedInAdapter,
    }
    if channel not in registry:
        raise ValueError(f"Unknown channel '{channel}'. Valid: {list(registry)}")
    return registry[channel]()
