"""
SMS channel via Twilio. Same note as email: DronaHQ ships a ready Twilio
connector - point an agent Tool at it in production and let this backend
just be the thing that logs the outcome to the CRM table. This direct
Twilio REST call exists so the channel works standalone too.
"""
import requests
from requests.auth import HTTPBasicAuth

from app.channels.base import ChannelAdapter, SendResult
from app.config import settings
from app.models import Lead


class SMSAdapter(ChannelAdapter):
    name = "sms"

    def send(self, lead: Lead, subject: str, content: str) -> SendResult:
        if settings.dry_run or not (settings.twilio_account_sid and settings.twilio_auth_token and lead.phone):
            return SendResult(
                status="dry_run",
                provider="twilio",
                meta={"to": lead.phone or "(no phone on file)", "body": content, "note": "DRY_RUN or missing Twilio config/lead phone"},
            )
        try:
            url = f"https://api.twilio.com/2010-04-01/Accounts/{settings.twilio_account_sid}/Messages.json"
            resp = requests.post(
                url,
                data={"From": settings.twilio_from_number, "To": lead.phone, "Body": content},
                auth=HTTPBasicAuth(settings.twilio_account_sid, settings.twilio_auth_token),
                timeout=20,
            )
            resp.raise_for_status()
            sid = resp.json().get("sid", "")
            return SendResult(status="sent", provider="twilio", provider_ref=sid)
        except Exception as e:
            return SendResult(status="failed", provider="twilio", meta={"error": str(e)})
