"""
Voice channel.

Deliberately thin: DronaHQ's native Voice Agent + Telephony + Campaigns
module is where outbound dialing, transcription, recording, and per-call
cost breakdown (STT/LLM/TTS) actually happen - reinventing that here would
duplicate a feature the platform already does well. This adapter's job is
just to queue a lead INTO a DronaHQ voice campaign and to receive the
result back via the /webhooks/dronahq-voice endpoint in app/main.py, which
writes the outcome into the Interaction (CRM) table.
"""
from app.channels.base import ChannelAdapter, SendResult
from app.config import settings
from app.models import Lead


class VoiceAdapter(ChannelAdapter):
    name = "voice"

    def send(self, lead: Lead, subject: str, content: str) -> SendResult:
        # "content" here is the call brief/context handed to the DronaHQ
        # voice agent, not a script to read verbatim.
        if settings.dry_run or not lead.phone:
            return SendResult(
                status="dry_run",
                provider="dronahq_voice",
                meta={"to": lead.phone or "(no phone on file)", "call_brief": content,
                      "note": "DRY_RUN, or no phone on file. Live mode enqueues into a DronaHQ "
                              "voice Campaign via its Developer API - see README 'Wiring up DronaHQ'."},
            )
        # TODO(live): POST to DronaHQ's voice-agent Campaign API to add this
        # lead to the outbound call list, using the agent's published API
        # key from DronaHQ -> Developer -> API Keys. Left unimplemented here
        # because it needs a real DronaHQ workspace/agent to target; the
        # webhook receiver below is what completes the loop once that call
        # finishes.
        return SendResult(status="failed", provider="dronahq_voice",
                           meta={"error": "Live DronaHQ voice wiring not configured - set DRY_RUN=true or "
                                           "implement the POST call described in the TODO."})
