"""
LinkedIn channel.

There is no compliant free LinkedIn API for sending connection requests or
messages at scale - LinkedIn's official API is partner-gated, and scraping
or automating a personal session violates its User Agreement (LinkedIn has
actively pursued legal action against companies doing exactly that). So
this adapter does one of two things:

  1. If LINKEDIN_PROVIDER_API_KEY is set, it calls out to a licensed
     provider (wire in Unipile or similar here - left as a TODO since it
     needs a real account to test against).
  2. Otherwise (the default), it queues the action into a human-in-the-loop
     review list instead of a hard failure - a rep reviews/sends it
     manually from their own logged-in LinkedIn account, and marks it done,
     which still gets logged to the CRM (Interaction) table for full
     funnel visibility.
"""
from app.channels.base import ChannelAdapter, SendResult
from app.config import settings
from app.models import Lead


class LinkedInAdapter(ChannelAdapter):
    name = "linkedin"

    def send(self, lead: Lead, subject: str, content: str) -> SendResult:
        if settings.linkedin_provider_api_key and not settings.dry_run:
            # TODO(live): call your licensed LinkedIn provider (e.g. Unipile)
            # here. Left unimplemented - needs a real provider account.
            return SendResult(status="failed", provider="linkedin_provider",
                               meta={"error": "Live LinkedIn provider call not implemented - see TODO."})

        return SendResult(
            status="dry_run",
            provider="human_review_queue",
            meta={
                "linkedin_url": lead.linkedin_url or "(no LinkedIn URL on file)",
                "message_draft": content,
                "note": "Queued for a human rep to send manually from their own LinkedIn account "
                        "and mark as sent - no compliant free/automated LinkedIn send exists.",
            },
        )
