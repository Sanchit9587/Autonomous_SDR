"""
Email channel. In production you'd usually route this through DronaHQ's
ready Gmail connector (an agent Tool), calling this backend only to log
the result. This SMTP path exists so the pipeline is independently runnable
outside DronaHQ too, for local development and the buildathon demo.
"""
import smtplib
from email.mime.text import MIMEText

from app.channels.base import ChannelAdapter, SendResult
from app.config import settings
from app.models import Lead


class EmailAdapter(ChannelAdapter):
    name = "email"

    def send(self, lead: Lead, subject: str, content: str) -> SendResult:
        if settings.dry_run or not (settings.smtp_host and settings.smtp_user and lead.email):
            return SendResult(
                status="dry_run",
                provider="smtp",
                meta={"to": lead.email or "(no email on file)", "subject": subject, "note": "DRY_RUN or missing SMTP config/lead email"},
            )
        try:
            msg = MIMEText(content)
            msg["Subject"] = subject
            msg["From"] = settings.smtp_from or settings.smtp_user
            msg["To"] = lead.email
            with smtplib.SMTP(settings.smtp_host, settings.smtp_port) as server:
                server.starttls()
                server.login(settings.smtp_user, settings.smtp_password)
                server.sendmail(msg["From"], [lead.email], msg.as_string())
            return SendResult(status="sent", provider="smtp", provider_ref=lead.email)
        except Exception as e:
            return SendResult(status="failed", provider="smtp", meta={"error": str(e)})
