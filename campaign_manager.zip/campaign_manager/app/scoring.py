"""
The ICP scoring engine.

Deliberately NOT a trained/ML classifier - there is no labeled dataset for
"good lead" and building one wasn't a good use of buildathon hours. Instead:

  1. A deterministic, weighted, fully-explainable rule score (title,
     seniority, experience, industry, location-gate, keyword signals).
  2. An optional similarity bonus against "reference profiles" - a handful
     of people the campaign manager already knows are a great fit. This is
     unsupervised nearest-neighbor scoring (TF-IDF cosine similarity over
     each person's title+headline+company text), not a fitted model, so it
     needs zero training data and works from day one on any vertical.

Both current-role AND employment-history are considered, controlled by
`title_match_mode`. This split exists because of a real test: a former
BFSI CIO who is now a VP at a different BFSI company, with no field that
is simultaneously "current title = CIO" true, still needs to be findable
for a campaign that explicitly wants ex-leaders/advisors.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Optional

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from app.models import Lead
from app.schemas import ICPFilter, ScoringWeights


SENIORITY_MAP = {
    "chief": "c_suite", "cio": "c_suite", "cto": "c_suite", "cdo": "c_suite",
    "ceo": "c_suite", "coo": "c_suite", "cfo": "c_suite", "ciso": "c_suite",
    "president": "c_suite", "founder": "c_suite",
    "vp": "vp", "vice president": "vp", "head of": "vp",
    "director": "director", "senior director": "director",
    "manager": "manager", "lead": "manager",
}


def infer_seniority(title: str) -> str:
    t = (title or "").lower()
    for key, tier in SENIORITY_MAP.items():
        if key in t:
            return tier
    return "other"


def _years_ago(date_str: str) -> Optional[float]:
    """Very forgiving 'YYYY-MM' / 'YYYY' / 'present' parser -> years-ago float."""
    if not date_str or date_str.lower() == "present":
        return 0.0
    for fmt in ("%Y-%m", "%Y"):
        try:
            d = dt.datetime.strptime(date_str, fmt)
            return (dt.datetime.utcnow() - d).days / 365.25
        except ValueError:
            continue
    return None


@dataclass
class ScoreResult:
    score: float
    breakdown: dict = field(default_factory=dict)
    stage: str = "scored"
    location_gate_passed: bool = True
    matched_role_titles: list = field(default_factory=list)
    matched_via: str = "current"  # "current" | "historical" | "none"


def _title_matches_any(title: str, role_titles: list[str]) -> bool:
    t = (title or "").lower()
    return any(rt.lower() in t for rt in role_titles) if role_titles else False


def _industry_matches_any(industry: str, industry_tags: list[str]) -> bool:
    ind = (industry or "").lower()
    return any(tag.lower() in ind for tag in industry_tags) if industry_tags else False


def _location_matches_any(location: str, allowed: list[str]) -> bool:
    if not allowed:
        return True  # no restriction configured = anywhere
    loc = (location or "").lower()
    return any(a.lower() in loc for a in allowed)


def score_lead(
    lead: Lead,
    icp: ICPFilter,
    weights: ScoringWeights,
    reference_corpus: Optional[list[str]] = None,
) -> ScoreResult:
    breakdown: dict = {}
    matched_via = "none"
    matched_role_titles: list[str] = []

    # ---- Hard gate: person location -------------------------------------
    location_gate_passed = _location_matches_any(lead.location, icp.person_location)

    # ---- Hard exclusion list ---------------------------------------------
    excl = [e.lower() for e in icp.exclusions]
    if excl and (
        (lead.current_company or "").lower() in excl
        or (lead.email or "").split("@")[-1].lower() in excl
        or (lead.full_name or "").lower() in excl
    ):
        return ScoreResult(score=0, breakdown={"excluded": True}, stage="rejected",
                            location_gate_passed=location_gate_passed, matched_via="excluded")

    # ---- Company HQ location (soft filter only if explicitly set) -------
    # Intentionally independent of person_location - the whole point of the
    # BFSI-CIO-in-India test: company HQ elsewhere should not disqualify a
    # person who is themselves based in the target location.
    company_loc_ok = _location_matches_any(lead.current_company, icp.company_location) if icp.company_location else True

    # ---- Current title / seniority ---------------------------------------
    current_title_hit = _title_matches_any(lead.current_title, icp.role_titles)
    current_seniority = infer_seniority(lead.current_title)
    if current_title_hit:
        breakdown["current_title_exact"] = weights.current_title_exact
        matched_via = "current"
        matched_role_titles.append(lead.current_title)

    # ---- Historical title (only if enabled) -------------------------------
    historical_hit = False
    if not current_title_hit and icp.title_match_mode == "current_or_historical":
        for role in lead.employment_history or []:
            title = role.get("title", "")
            end = role.get("end", "")
            years_ago = _years_ago(end) if end and end.lower() != "present" else 0.0
            if _title_matches_any(title, icp.role_titles) and (
                years_ago is None or years_ago <= icp.historical_lookback_years
            ):
                historical_hit = True
                matched_via = "historical"
                matched_role_titles.append(title)
                break
    if historical_hit:
        breakdown["historical_title_within_lookback"] = weights.historical_title_within_lookback

    # ---- Seniority match (current, plus historical role's tier if that's
    #      what matched) ----------------------------------------------------
    seniority_hit = current_seniority in icp.seniority if icp.seniority else False
    if not seniority_hit and historical_hit:
        for role in lead.employment_history or []:
            if role.get("title") in matched_role_titles:
                if infer_seniority(role.get("title", "")) in icp.seniority:
                    seniority_hit = True
                break
    if seniority_hit:
        breakdown["seniority_match"] = weights.seniority_match

    # ---- Years of experience ----------------------------------------------
    if lead.total_years_experience >= icp.min_years_experience:
        breakdown["yoe_meets_floor"] = weights.yoe_meets_floor

    # ---- Industry (current, or current-or-historical per mode) -----------
    industry_hit = _industry_matches_any(lead.current_industry, icp.industry_tags)
    if not industry_hit and icp.title_match_mode == "current_or_historical":
        for role in lead.employment_history or []:
            end = role.get("end", "")
            years_ago = _years_ago(end) if end and end.lower() != "present" else 0.0
            if _industry_matches_any(role.get("industry", ""), icp.industry_tags) and (
                years_ago is None or years_ago <= icp.historical_lookback_years
            ):
                industry_hit = True
                break
    if industry_hit:
        breakdown["industry_match"] = weights.industry_match

    # ---- Free-text signal tags (headline / bio) ---------------------------
    haystack = (lead.headline or "").lower()
    signal_hit = any(tag.lower() in haystack for tag in icp.signal_tags) if icp.signal_tags else False
    if signal_hit:
        breakdown["signal_tag_match"] = weights.signal_tag_match

    # ---- Reference-profile similarity (unsupervised, no training data) ---
    ref_bonus = 0.0
    if reference_corpus:
        lead_text = " ".join(filter(None, [lead.current_title, lead.current_company, lead.headline]))
        corpus = reference_corpus + [lead_text]
        try:
            vec = TfidfVectorizer(stop_words="english").fit_transform(corpus)
            sims = cosine_similarity(vec[-1], vec[:-1])[0]
            best = float(max(sims)) if len(sims) else 0.0
            ref_bonus = round(best * weights.reference_similarity_max, 2)
            if ref_bonus > 0:
                breakdown["reference_profile_similarity"] = ref_bonus
        except ValueError:
            pass

    raw_score = sum(v for k, v in breakdown.items() if isinstance(v, (int, float)))
    final_score = raw_score if location_gate_passed and company_loc_ok else 0.0

    if not location_gate_passed:
        breakdown["_gate_failed"] = "person_location"
    if not company_loc_ok:
        breakdown["_gate_failed_company_location"] = True

    if final_score >= weights.auto_qualify_threshold:
        stage = "qualified"
    elif final_score >= weights.review_min_threshold:
        stage = "in_review"
    else:
        stage = "rejected"

    return ScoreResult(
        score=round(final_score, 2),
        breakdown=breakdown,
        stage=stage,
        location_gate_passed=location_gate_passed,
        matched_role_titles=matched_role_titles,
        matched_via=matched_via,
    )
