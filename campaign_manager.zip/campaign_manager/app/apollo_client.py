"""
Thin Apollo.io client.

Two modes:
  - "demo"  -> reads from app/fixtures/demo_leads.json (the real, live
               data pulled from Apollo during ICP validation for this
               project - including the Shalu Chadha dual-campaign test
               case). Runs with zero API key, zero credits spent.
  - "live"  -> calls Apollo's real People Search API with APOLLO_API_KEY.
               Some endpoints are plan-gated on Apollo's side (their own
               error message says so plainly) - this client surfaces that
               error rather than pretending the search returned nothing.

Swap modes at any time via the APOLLO_MODE env var, no code changes needed.
"""
import json
import os
from typing import Optional

import requests

from app.config import settings
from app.schemas import ICPFilter, EmploymentRecord

FIXTURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fixtures")


class ApolloError(Exception):
    pass


def _load_demo_leads() -> list[dict]:
    path = os.path.join(FIXTURES_DIR, "demo_leads.json")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def search_people(icp: ICPFilter, limit: int = 200) -> list[dict]:
    """Returns a list of lead dicts matching app.schemas.LeadIn shape."""
    if settings.apollo_mode == "live":
        return _search_people_live(icp, limit)
    return _search_people_demo(icp, limit)


def _search_people_demo(icp: ICPFilter, limit: int) -> list[dict]:
    leads = _load_demo_leads()
    return leads[:limit]


def _search_people_live(icp: ICPFilter, limit: int) -> list[dict]:
    if not settings.apollo_api_key:
        raise ApolloError("APOLLO_MODE=live but APOLLO_API_KEY is not set.")

    payload = {
        "person_titles": icp.role_titles,
        "person_locations": icp.person_location,
        "organization_locations": icp.company_location,
        "q_organization_keyword_tags": icp.industry_tags,
        "person_seniorities": icp.seniority,
        "per_page": min(limit, 100),
    }
    headers = {"X-Api-Key": settings.apollo_api_key, "Content-Type": "application/json"}
    resp = requests.post(
        "https://api.apollo.io/v1/mixed_people/search",
        headers=headers,
        json=payload,
        timeout=30,
    )
    if resp.status_code == 403:
        raise ApolloError(
            "Apollo rejected this endpoint for your plan (403). This project was validated "
            "against a Free-tier account where the raw search API is plan-gated - either "
            "upgrade the Apollo plan, or keep APOLLO_MODE=demo for development."
        )
    resp.raise_for_status()
    data = resp.json()

    leads = []
    for p in data.get("people", []):
        org = p.get("organization") or {}
        leads.append({
            "full_name": p.get("name", ""),
            "current_title": p.get("title", ""),
            "current_company": org.get("name", ""),
            "current_industry": org.get("industry", ""),
            "location": ", ".join(filter(None, [p.get("city"), p.get("state"), p.get("country")])),
            "total_years_experience": p.get("total_years_experience") or 0,
            "headline": p.get("headline", ""),
            "linkedin_url": p.get("linkedin_url", ""),
            "email": p.get("email", "") or "",
            "phone": p.get("phone", "") or "",
            "apollo_id": p.get("id", ""),
            "employment_history": [],  # live API's employment_history parsing left as a TODO -
                                        # see README for the historical-title enrichment call.
            "source_note": "apollo_live",
        })
    return leads


def match_person(name: str, organization_name: Optional[str] = None) -> Optional[dict]:
    """Direct name(+company) lookup - the right tool for a recall/coverage
    test, as opposed to a filtered list search."""
    if settings.apollo_mode == "demo":
        for lead in _load_demo_leads():
            if lead["full_name"].lower() == name.lower():
                return lead
        return None

    if not settings.apollo_api_key:
        raise ApolloError("APOLLO_MODE=live but APOLLO_API_KEY is not set.")
    headers = {"X-Api-Key": settings.apollo_api_key, "Content-Type": "application/json"}
    params = {"name": name}
    if organization_name:
        params["organization_name"] = organization_name
    resp = requests.post("https://api.apollo.io/v1/people/match", headers=headers, json=params, timeout=30)
    if resp.status_code == 403:
        raise ApolloError("Apollo rejected /people/match for your plan (403). Use APOLLO_MODE=demo, or upgrade.")
    resp.raise_for_status()
    person = resp.json().get("person")
    return person
