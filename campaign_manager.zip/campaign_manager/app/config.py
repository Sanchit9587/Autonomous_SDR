"""
Central configuration. Every setting has a safe default so the app runs
end-to-end with zero credentials configured (demo/dry-run mode) - flip the
env vars in .env to point it at real Apollo credits and real channels.
"""
import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Settings:
    # Database
    database_url: str = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR}/data/campaign_manager.db")

    # Lead sourcing
    apollo_api_key: str = os.getenv("APOLLO_API_KEY", "")
    apollo_mode: str = os.getenv("APOLLO_MODE", "demo")  # "demo" | "live"

    # AI explanation
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")

    # Channels
    dry_run: bool = os.getenv("DRY_RUN", "true").lower() == "true"

    smtp_host: str = os.getenv("SMTP_HOST", "")
    smtp_port: int = int(os.getenv("SMTP_PORT", "587"))
    smtp_user: str = os.getenv("SMTP_USER", "")
    smtp_password: str = os.getenv("SMTP_PASSWORD", "")
    smtp_from: str = os.getenv("SMTP_FROM", "")

    twilio_account_sid: str = os.getenv("TWILIO_ACCOUNT_SID", "")
    twilio_auth_token: str = os.getenv("TWILIO_AUTH_TOKEN", "")
    twilio_from_number: str = os.getenv("TWILIO_FROM_NUMBER", "")

    dronahq_voice_webhook_secret: str = os.getenv("DRONAHQ_VOICE_WEBHOOK_SECRET", "")
    linkedin_provider_api_key: str = os.getenv("LINKEDIN_PROVIDER_API_KEY", "")

    api_base_url: str = os.getenv("API_BASE_URL", "http://localhost:8000")


settings = Settings()
