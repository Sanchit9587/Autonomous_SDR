"""
Data model.

Campaign        -> owns an ICP filter (JSON) + channel config + scoring weights.
PromptVersion    -> versioned instruction text per campaign/agent, so every
                    action a lead ever received can point at exactly which
                    version produced it (auditability the rubric asks for).
Lead             -> a person, plus their current role AND employment history
                    (so "current vs historical title" matching is possible).
LeadScore        -> the score breakdown + explanation for one lead under one
                    campaign's ICP (a lead can be scored differently by two
                    different campaigns - this is the Shalu Chadha case).
Interaction      -> every outbound/inbound touch on a lead, across every
                    channel - this is the CRM log the brief asks for.
"""
import datetime as dt
import enum
import uuid

from sqlalchemy import String, Text, Integer, Float, Boolean, ForeignKey, DateTime, JSON, Enum
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db import Base


def gen_id() -> str:
    return uuid.uuid4().hex[:16]


class CampaignStatus(str, enum.Enum):
    draft = "draft"
    active = "active"
    paused = "paused"
    completed = "completed"


class Channel(str, enum.Enum):
    email = "email"
    sms = "sms"
    voice = "voice"
    linkedin = "linkedin"


class InteractionDirection(str, enum.Enum):
    outbound = "outbound"
    inbound = "inbound"


class LeadStage(str, enum.Enum):
    new = "new"
    scored = "scored"
    qualified = "qualified"
    in_review = "in_review"
    rejected = "rejected"
    contacted = "contacted"
    responded = "responded"
    meeting_booked = "meeting_booked"
    do_not_contact = "do_not_contact"


class Campaign(Base):
    __tablename__ = "campaigns"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_id)
    name: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[CampaignStatus] = mapped_column(Enum(CampaignStatus), default=CampaignStatus.draft)

    # The ICP filter schema - see app/scoring.py for the field contract.
    icp_filter: Mapped[dict] = mapped_column(JSON, default=dict)

    # Scoring weights, overridable per campaign; defaults applied if empty.
    scoring_weights: Mapped[dict] = mapped_column(JSON, default=dict)

    # Which channels are enabled for this campaign.
    enabled_channels: Mapped[list] = mapped_column(JSON, default=list)

    daily_send_limit: Mapped[int] = mapped_column(Integer, default=50)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=dt.datetime.utcnow)
    updated_at: Mapped[dt.datetime] = mapped_column(DateTime, default=dt.datetime.utcnow, onupdate=dt.datetime.utcnow)

    prompt_versions: Mapped[list["PromptVersion"]] = relationship(back_populates="campaign")
    lead_scores: Mapped[list["LeadScore"]] = relationship(back_populates="campaign")


class PromptVersion(Base):
    """Every agent instruction is versioned so we can answer 'why did the
    agent do that' by pointing at exactly the text that was live at the time."""

    __tablename__ = "prompt_versions"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_id)
    campaign_id: Mapped[str] = mapped_column(ForeignKey("campaigns.id"))
    agent_name: Mapped[str] = mapped_column(String)  # e.g. "icp_fitment", "personalization", "conversation"
    version: Mapped[int] = mapped_column(Integer, default=1)
    instruction_text: Mapped[str] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=dt.datetime.utcnow)

    campaign: Mapped["Campaign"] = relationship(back_populates="prompt_versions")


class Lead(Base):
    __tablename__ = "leads"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_id)
    full_name: Mapped[str] = mapped_column(String, nullable=False)

    current_title: Mapped[str] = mapped_column(String, default="")
    current_company: Mapped[str] = mapped_column(String, default="")
    current_industry: Mapped[str] = mapped_column(String, default="")
    location: Mapped[str] = mapped_column(String, default="")
    total_years_experience: Mapped[float] = mapped_column(Float, default=0.0)
    headline: Mapped[str] = mapped_column(Text, default="")  # LinkedIn-style headline/bio

    linkedin_url: Mapped[str] = mapped_column(String, default="")
    email: Mapped[str] = mapped_column(String, default="")
    phone: Mapped[str] = mapped_column(String, default="")

    apollo_id: Mapped[str] = mapped_column(String, default="")

    # List of {"company", "title", "industry", "start", "end"} dicts, most
    # recent first. This is what makes historical-title matching possible.
    employment_history: Mapped[list] = mapped_column(JSON, default=list)

    source_note: Mapped[str] = mapped_column(String, default="")  # where this record came from
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=dt.datetime.utcnow)

    scores: Mapped[list["LeadScore"]] = relationship(back_populates="lead")
    interactions: Mapped[list["Interaction"]] = relationship(back_populates="lead")


class LeadScore(Base):
    """A lead's fit score under ONE campaign's ICP. Deliberately not unique
    per-lead: the same person can score very differently under a different
    campaign's filter (this is exactly the Shalu Chadha case)."""

    __tablename__ = "lead_scores"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_id)
    lead_id: Mapped[str] = mapped_column(ForeignKey("leads.id"))
    campaign_id: Mapped[str] = mapped_column(ForeignKey("campaigns.id"))

    score: Mapped[float] = mapped_column(Float)
    stage: Mapped[LeadStage] = mapped_column(Enum(LeadStage), default=LeadStage.scored)
    breakdown: Mapped[dict] = mapped_column(JSON, default=dict)   # per-signal points, see scoring.py
    explanation: Mapped[str] = mapped_column(Text, default="")     # human-readable "why"
    location_gate_passed: Mapped[bool] = mapped_column(Boolean, default=True)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=dt.datetime.utcnow)

    lead: Mapped["Lead"] = relationship(back_populates="scores")
    campaign: Mapped["Campaign"] = relationship(back_populates="lead_scores")


class Interaction(Base):
    """Every touch on a lead, on any channel - this table IS the CRM log."""

    __tablename__ = "interactions"

    id: Mapped[str] = mapped_column(String, primary_key=True, default=gen_id)
    lead_id: Mapped[str] = mapped_column(ForeignKey("leads.id"))
    campaign_id: Mapped[str] = mapped_column(ForeignKey("campaigns.id"))
    prompt_version_id: Mapped[str] = mapped_column(String, default="")

    channel: Mapped[Channel] = mapped_column(Enum(Channel))
    direction: Mapped[InteractionDirection] = mapped_column(Enum(InteractionDirection), default=InteractionDirection.outbound)

    subject: Mapped[str] = mapped_column(String, default="")
    content: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String, default="queued")  # queued|sent|failed|dry_run|delivered|replied
    provider: Mapped[str] = mapped_column(String, default="")       # e.g. "twilio", "smtp", "dronahq_voice"
    provider_ref: Mapped[str] = mapped_column(String, default="")   # external message/call id
    meta: Mapped[dict] = mapped_column(JSON, default=dict)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=dt.datetime.utcnow)

    lead: Mapped["Lead"] = relationship(back_populates="interactions")
