# AI SDR - Campaign Manager (Orchestration Backend + Control Panel)

Runnable code for the "control panel" + "intelligence layer" + "analytics
layer" pieces of the buildathon project. It runs standalone today (zero
external accounts needed, demo mode uses real Apollo data we already
pulled), and it's built so DronaHQ agents can call the same REST API
instead of you rebuilding this logic inside DronaHQ.

## What this proves, concretely

Same real person, two campaigns, two different (both correct) outcomes:

| Campaign | ICP mode | Shalu Chadha's score | Outcome |
|---|---|---|---|
| "BFSI Tech Leaders - India" | `current_only` title match | 30/100 | Rejected |
| "Ex-BFSI Leaders & Advisors - India" | `current_or_historical` (5yr lookback) | 77/100 | Auto-qualified |

She's a real former PepsiCo India CIO now a VP at Chubb. A naive
current-title-only filter correctly excludes her from an "active CIO"
campaign, and a wider filter correctly includes her in an "ex-leader /
advisor" campaign - same data, different ICP, different (both right)
answer. `scripts/seed_demo.py` reproduces this end to end.

## Quick start

```bash
python3 -m venv venv
source venv/bin/activate            # Windows: venv\Scripts\activate
pip install -r requirements.txt

# 1) generate the demo lead fixture (real, validated Apollo data - no API key needed)
python scripts/generate_demo_fixture.py

# 2) start the backend
uvicorn app.main:app --reload --port 8000
# Swagger UI: http://localhost:8000/docs

# 3) in a second terminal: seed two demo campaigns and run the scoring pipeline
source venv/bin/activate
python scripts/seed_demo.py

# 4) in a third terminal: the manager-facing control panel
source venv/bin/activate
streamlit run control_panel.py
```

Open the Streamlit URL it prints, pick a campaign in the sidebar, click
**Run lead search**, and browse the scored leads with their explanations.

## Architecture

```
Streamlit control panel  --HTTP-->  FastAPI backend (app/main.py)
DronaHQ agent (Connector/Code tool) --HTTP--/         |
                                                       |-- app/apollo_client.py   (lead sourcing)
                                                       |-- app/scoring.py         (ICP fit scoring)
                                                       |-- app/explain.py         (grounded explanation)
                                                       |-- app/channels/*         (email/sms/voice/linkedin)
                                                       |-- SQLite (Campaign, Lead, LeadScore, Interaction)
```

**Why a backend + control panel, not just DronaHQ?** DronaHQ owns the
agent brains and the channel execution (its native Voice Agent +
Telephony + Campaigns module, its Gmail/Twilio connectors). This backend
owns the parts DronaHQ doesn't provide out of the box: the ICP scoring
formula, the current-vs-historical matching logic, campaign-scoped state,
and the CRM interaction log. Point a DronaHQ agent's "Code" or "Connector"
tool at this API's routes (they're all in `app/main.py`, and Swagger UI
at `/docs` documents every one) and DronaHQ becomes the channel/voice
layer on top of this engine, instead of you re-implementing scoring logic
inside a DronaHQ agent instruction.

## The ICP filter schema (`app/schemas.py::ICPFilter`)

Works for any vertical, not just BFSI - see `app/scoring.py` for the full
weighting logic:

| Field | Meaning |
|---|---|
| `role_titles` | target job titles |
| `seniority` | c_suite / vp / director / manager |
| `min_years_experience` | floor |
| `industry_tags` | target industries |
| `person_location` | where the HUMAN sits (hard gate) |
| `company_location` | where the employer HQ sits - leave blank for "anywhere" |
| `title_match_mode` | `current_only` or `current_or_historical` |
| `historical_lookback_years` | how far back a past role still counts |
| `signal_tags` | free-text keywords matched against headline/bio (catches "advisor", "board member", etc.) |
| `reference_profiles` | 1-10 "golden example" descriptions - new leads get a similarity bonus (TF-IDF cosine, zero training data needed) |
| `exclusions` | hard block-list (competitors, existing customers) |

`person_location` and `company_location` are always separate fields on
purpose - that's what makes "BFSI CIO in India" correctly include the
India-based CIO of a global company headquartered elsewhere.

## Scoring (`app/scoring.py`)

Deliberately not a trained ML model - there's no labeled "good lead"
dataset, and one wasn't worth building in a time-boxed buildathon. It's a
deterministic, fully explainable weighted score:

`current_title_exact (30) + historical_title_within_lookback (18, only if
current didn't hit) + seniority_match (15) + yoe_meets_floor (15) +
industry_match (15, current-or-historical) + signal_tag_match (10) +
reference_profile_similarity (up to 15, TF-IDF cosine to your golden
examples)`, gated hard by `person_location` (score forced to 0 if it
fails). Thresholds (`>=70` qualify, `40-69` human review, `<40` reject)
live in `ScoringWeights` and are overridable per campaign.

## Explanation (`app/explain.py`)

Always grounded in the structured breakdown above - never free-form. If
`ANTHROPIC_API_KEY` is set, Claude rephrases those exact facts more
naturally (still fed nothing else, so it can't invent a reason); otherwise
a deterministic template does the job. The app never depends on having an
LLM key to explain a score.

## Channels (`app/channels/`)

Every adapter shares one interface (`send(lead, subject, content)`) and
defaults to `DRY_RUN=true`: with no provider creds configured, actions are
logged to the CRM/Interaction table as `dry_run` instead of actually going
out, so the whole pipeline (including the control panel's Outreach tab) is
demoable with zero external accounts.

- **email** - direct SMTP, or route through DronaHQ's Gmail connector instead.
- **sms** - direct Twilio REST, or route through DronaHQ's Twilio connector instead.
- **voice** - intentionally thin. DronaHQ's native Voice Agent + Telephony +
  Campaigns module should own actual dialing/transcription/recording/cost
  breakdown - reinventing that here would duplicate a feature the platform
  already does well. `POST /webhooks/dronahq-voice` is where DronaHQ posts
  a finished call's result back into this app's CRM log.
- **linkedin** - there is no compliant free LinkedIn API for sending at
  scale (official API is partner-gated; scraping/automating a personal
  session breaches LinkedIn's User Agreement and has drawn real legal
  action against companies that did it). Default behavior queues the
  drafted message into a human-review list a rep sends manually from their
  own account; wire in a licensed provider (e.g. Unipile) in
  `app/channels/linkedin_channel.py` if you have one.

## Wiring up real Apollo data

Set in `.env` (copy from `.env.example`):
```
APOLLO_MODE=live
APOLLO_API_KEY=your_key_here
```
Some Apollo endpoints are plan-gated (their own API returns a clear 403 +
message when that happens) - `app/apollo_client.py` surfaces that error
rather than silently returning nothing. Leave `APOLLO_MODE=demo` (default)
to keep working against the validated fixture data.

## What's a stub vs. what's real

**Real and tested:** the full scoring engine, the current-vs-historical
title logic, campaign CRUD, the FastAPI routes, the Streamlit control
panel, CRM/interaction logging, the analytics rollups, dry-run outreach
logging - all exercised end-to-end by `scripts/seed_demo.py`.

**Stubs with a clear TODO, by design:** the live Twilio/SMTP sends work if
you supply real credentials; the DronaHQ voice-campaign POST and the
LinkedIn provider call are left as marked TODOs in
`app/channels/voice_channel.py` and `linkedin_channel.py` - both need a
real DronaHQ workspace / licensed LinkedIn provider account to build and
test against, which is why they're not faked here.
