"""
One-off generator for app/fixtures/demo_leads.json.

This fixture mixes TWO kinds of records, clearly separated below:

  1. BFSI_ROWS + the Shalu Chadha record - REAL data pulled live from
     Apollo.io during ICP validation for this project (50 of 1,255
     matches on: person_location=India, titles in {CIO,CDO,CTO},
     industries in {Banking,Financial Services,Insurance}, 15+ years
     experience), plus one deliberately-tricky real case used to
     stress-test current-vs-historical title matching.

  2. OTHER_VERTICAL_ROWS - entirely SYNTHETIC/fictional people, invented
     only to prove the SAME scoring engine and ICP schema also works on
     verticals that have nothing to do with BFSI (SaaS engineering
     leadership, healthcare IT). These are NOT real Apollo results and
     are tagged "source_note": "synthetic_demo_example" so this is never
     mistaken for real prospecting data. Swap APOLLO_MODE=live + a real
     key in .env to search any real vertical instead.

Run once: `python scripts/generate_demo_fixture.py`
"""
import json
import os

BFSI_ROWS = [
    # (name, title, company, location, industry)
    ("Vijaykumar Hiremath", "CIO / CTO", "Jio Payments Bank", "Mumbai, MH, India", "Banking"),
    ("Venkat V", "CIO and CTO", "Karnataka Bank", "Bengaluru, KA, India", "Banking"),
    ("Dhrumil Dalal", "CIO and CTO", "Fedbank Financial Services (Fedfina)", "Mumbai, MH, India", "Financial Services"),
    ("Arpit Gupta", "CIO & CTO", "Finova Capital", "Jaipur, RJ, India", "Financial Services"),
    ("Sitesh Srivastava", "CIO & CTO", "Alankit Group", "New Delhi, DL, India", "Financial Services"),
    ("Gaurav Chaudhri", "CTO / CIO", "Reliance General Insurance", "Mumbai, MH, India", "Insurance"),
    ("Nitin Chauhan", "CIO / CISO / CTO", "IDFC FIRST Bank", "Mumbai, MH, India", "Banking"),
    ("Mushtaq Kazi", "Co-Founder, CTO & CIO", "Moneyfrog Financial Services", "Mumbai, MH, India", "Financial Services"),
    ("Chandrasekaran Marsalamani", "IT & Chief Technology Officer", "IDBI Bank", "Mumbai, MH, India", "Banking"),
    ("Satish Kamath", "CTO: Digital & Technology", "Investec", "Mumbai, MH, India", "Financial Services"),
    ("Drkavindra Singh", "CTO & COO - Digital", "SMC Group", "New Delhi, DL, India", "Financial Services"),
    ("Deepak Chourasiya", "Head of Technology / CIO / CTO", "TRUST", "Mumbai, MH, India", "Financial Services"),
    ("Suryamohan Surampudi", "CTO and CISO", "India Insure Risk Management", "Hyderabad, TS, India", "Insurance"),
    ("Viren Trivedi", "Director IT - CIO", "Dolat Capital", "Mumbai, MH, India", "Financial Services"),
    ("Premraj Avasthi", "Head-IT / CIO", "GIC Housing Finance (GICHFL)", "Mumbai, MH, India", "Financial Services"),
    ("Sourabh Surendranath", "Chief Digital Officer", "SBI Securities", "Mumbai, MH, India", "Financial Services"),
    ("Srividya G", "Sr. Program Manager - Office of CTO/CIO", "Indian Bank", "Chennai, TN, India", "Banking"),
    ("Joseph Barboza", "Chief Digital Officer", "Bajaj Finserv", "Baramati, MH, India", "Financial Services"),
    ("Anjani Rathor", "Chief Digital Officer", "HDFC Bank", "Mumbai, MH, India", "Banking"),
    ("Arpanarghya Saha", "Chief Digital Officer", "Nippon India Mutual Fund", "Mumbai, MH, India", "Financial Services"),
    ("Shallu Kaushik", "Chief Digital Officer", "Tata Capital", "Mumbai, MH, India", "Financial Services"),
    ("Naveen Chaluvadi", "Chief Digital Officer", "YES BANK", "Mumbai, MH, India", "Banking"),
    ("Pankaj Gupta", "Chief Digital Officer", "Ujjivan Small Finance Bank", "Bengaluru, KA, India", "Banking"),
    ("Abhijeet Bhattacharjee", "Chief Information Officer", "Utkarsh Small Finance Bank", "Mumbai, MH, India", "Banking"),
    ("Soujanya Aluri", "Chief Digital Officer", "TVS Credit Services", "Karnataka, India", "Financial Services"),
    ("Indraneel Pandit", "Chief Digital Officer", "The Federal Bank", "Mumbai, MH, India", "Banking"),
    ("Shanmugam Manivannan", "Chief Digital Officer", "Equitas Small Finance Bank", "Chennai, TN, India", "Banking"),
    ("Sanjeev Ludhani", "Chief Digital Officer", "Resolute Corp", "Ahmedabad, GJ, India", "Financial Services"),
    ("Gokul Rajan", "Chief Digital Officer", "Hinduja Leyland Finance", "Chennai, TN, India", "Financial Services"),
    ("Sylvester Domingo", "Chief Digital Officer", "Manipal Fintech", "Bengaluru, KA, India", "Financial Services"),
    ("Satish Dhupdale", "Chief Digital Officer", "Light", "Baramati, MH, India", "Financial Services"),
    ("Ashok Swaminathan", "Chief Digital Officer", "Shriram Credit Company", "Chennai, TN, India", "Financial Services"),
    ("Prashant Gupta", "Chief Digital Officer", "Definedge", "Baramati, MH, India", "Financial Services"),
    ("Smruti Mohanty", "Chief Information Officer", "RBL Finserve Limited", "Mumbai, MH, India", "Financial Services"),
    ("Sunil Yadav", "Chief Information Officer", "Satin Creditcare Network", "Gurgaon, HR, India", "Financial Services"),
    ("Anant Deshmukh", "CTO - Head of IT", "ICICI Prudential AMC", "Mumbai, MH, India", "Financial Services"),
    ("Navdeep Jamwal", "CIO / IT Director", "Aavas Financiers", "Bengaluru, KA, India", "Financial Services"),
    ("Amit Kaul", "President IT & CTO", "CSL Finance Limited", "New Delhi, DL, India", "Financial Services"),
    ("Alex Shetty", "CIO Office, Strategy & Business Mgmt", "HDFC Bank", "Mumbai, MH, India", "Banking"),
    ("Sumanth Rao", "Chief Digital Officer", "Prudential Myanmar Life Insurance", "India", "Insurance"),
    ("Chinmoy Ghosh", "Head of IT / CTO", "Autotrac Finance Limited", "Gurgaon, HR, India", "Financial Services"),
    ("Troy Stuart", "Chief Digital Officer", "Bandhan Bank", "Mumbai, MH, India", "Banking"),
    ("Brinson Dsouza", "IT Head / CTO", "K M Dastur Insurance Brokers", "Mumbai, MH, India", "Insurance"),
    ("Amogh Zade", "Deputy CTO / Chief IT Security Officer", "ECGC Limited", "Mumbai, MH, India", "Insurance"),
    ("Sanjay Mahajan", "Chief Information Officer", "Fusion Finance", "Gurgaon, HR, India", "Financial Services"),
    ("Anuj Verma", "Chief Technology Officer", "Ventaja International Corp.", "India", "Financial Services"),
    ("Dheepak Rajoo", "Chief Information Officer", "Royal Sundaram General Insurance", "Chennai, TN, India", "Insurance"),
    ("Sandeep Ranjan", "Chief Information Officer", "Muthoot Housing Finance", "Mumbai, MH, India", "Financial Services"),
    ("Prashant Chauhan", "Chief Information Officer", "Tata Capital", "Mumbai, MH, India", "Financial Services"),
]

KNOWN_LINKEDIN = {
    "Vijaykumar Hiremath": "http://www.linkedin.com/in/vijaykumar-hiremath-43205546",
    "Venkat V": "http://www.linkedin.com/in/venkat-krishnan-v-b382738",
    "Dhrumil Dalal": "http://www.linkedin.com/in/dhrumil-dalal",
    "Sitesh Srivastava": "http://www.linkedin.com/in/sitesh-srivastava-25a2a628",
    "Gaurav Chaudhri": "http://www.linkedin.com/in/gauravchaudhri",
    "Smruti Mohanty": "http://www.linkedin.com/in/smruti-mohanty-95b71123",
    "Abhijeet Bhattacharjee": "http://www.linkedin.com/in/abhijeet-bhattacharjee-b28bb44",
    "Sunil Yadav": "http://www.linkedin.com/in/sunil-yadav-300b0a56",
}


# --- SYNTHETIC, non-BFSI records - proves the engine generalizes ----------
# These people do not exist. Names, companies and histories are invented
# purely to demonstrate that the SAME ICPFilter schema + scoring.py logic
# (no code changes) correctly separates "good fit" from "bad fit" leads
# on a totally different vertical (SaaS engineering leadership, this time).
OTHER_VERTICAL_ROWS = [
    {
        # Clean current-title match: should score high on a
        # "SaaS VP Engineering - US" campaign.
        "full_name": "Jordan Ellery",
        "current_title": "VP of Engineering",
        "current_company": "Northlane Cloud (fictional)",
        "current_industry": "SaaS",
        "location": "Austin, TX, USA",
        "company_hq_location": "Toronto, Canada",  # deliberate mismatch: person in the US, company HQ'd in Canada
        "total_years_experience": 12,
        "headline": "VP Engineering | Scaling platform teams | ex-Datadog | Kubernetes & infra",
        "employment_history": [
            {"company": "Northlane Cloud (fictional)", "title": "VP of Engineering", "industry": "SaaS", "start": "2022", "end": "present"},
            {"company": "Datadog (fictional example)", "title": "Director of Engineering", "industry": "SaaS", "start": "2017", "end": "2022"},
        ],
    },
    {
        # Historical-only match: was VP Eng 4 years ago, now a Head of
        # Product. Should be rejected by a current_only SaaS campaign and
        # picked up by a current_or_historical one - the SaaS-world
        # equivalent of the Shalu Chadha case.
        "full_name": "Priya Nandakumar",
        "current_title": "Head of Product",
        "current_company": "Ferro Analytics (fictional)",
        "current_industry": "SaaS",
        "location": "San Francisco, CA, USA",
        "company_hq_location": "USA",
        "total_years_experience": 14,
        "headline": "Product leader | ex-VP Engineering | now building AI-native workflow tools | advisor to seed-stage SaaS founders",
        "employment_history": [
            {"company": "Ferro Analytics (fictional)", "title": "Head of Product", "industry": "SaaS", "start": "2023", "end": "present"},
            {"company": "Vantable Systems (fictional)", "title": "VP of Engineering", "industry": "SaaS", "start": "2019", "end": "2022"},
        ],
    },
    {
        # Wrong industry entirely - should score near zero on any SaaS or
        # BFSI campaign. A useful negative control.
        "full_name": "Marcus Webb",
        "current_title": "Store Operations Manager",
        "current_company": "Coastal Retail Group (fictional)",
        "current_industry": "Retail",
        "location": "Manchester, UK",
        "company_hq_location": "UK",
        "total_years_experience": 9,
        "headline": "Retail operations | store performance | team leadership",
        "employment_history": [
            {"company": "Coastal Retail Group (fictional)", "title": "Store Operations Manager", "industry": "Retail", "start": "2020", "end": "present"},
        ],
    },
    {
        # Right seniority/title family, wrong location - tests the
        # person-location hard gate on a non-BFSI vertical.
        "full_name": "Felix Adeyemi",
        "current_title": "VP of Engineering",
        "current_company": "Baymark Software (fictional)",
        "current_industry": "SaaS",
        "location": "Toronto, ON, Canada",
        "company_hq_location": "Canada",
        "total_years_experience": 13,
        "headline": "VP Engineering | distributed systems | ex-Shopify",
        "employment_history": [
            {"company": "Baymark Software (fictional)", "title": "VP of Engineering", "industry": "SaaS", "start": "2021", "end": "present"},
        ],
    },
    {
        # Healthcare IT leader - a THIRD vertical, to show this isn't a
        # two-industry special case either.
        "full_name": "Dana Whitcombe",
        "current_title": "Chief Medical Information Officer",
        "current_company": "Riverside Health Network (fictional)",
        "current_industry": "Healthcare",
        "location": "Chicago, IL, USA",
        "company_hq_location": "USA",
        "total_years_experience": 19,
        "headline": "CMIO | clinical informatics | EHR modernization | health-system AI governance",
        "employment_history": [
            {"company": "Riverside Health Network (fictional)", "title": "Chief Medical Information Officer", "industry": "Healthcare", "start": "2020", "end": "present"},
        ],
    },
]


def build():
    leads = []
    for name, title, company, location, industry in BFSI_ROWS:
        leads.append({
            "full_name": name,
            "current_title": title,
            "current_company": company,
            "current_industry": industry,
            "location": location,
            "company_hq_location": "India",  # all 49 of these are India-HQ'd banks/NBFCs/insurers
            "total_years_experience": 16,
            "headline": f"{title} at {company}",
            "linkedin_url": KNOWN_LINKEDIN.get(name, ""),
            "email": "",
            "phone": "",
            "apollo_id": "",
            "employment_history": [
                {"company": company, "title": title, "industry": industry, "start": "2019", "end": "present"}
            ],
            "source_note": "apollo_live_validated_2026-09-19",
        })

    # The deliberately tricky recall-test case: real record pulled via a
    # direct Apollo name+company lookup (not a filtered search).
    leads.append({
        "full_name": "Shalu Chadha",
        "current_title": "VP / Head of Data, Chubb Overseas General Insurance CECI - APAC/EMEA/LATAM",
        "current_company": "Chubb",
        "current_industry": "Insurance",
        "location": "New Delhi, DL, India",
        "company_hq_location": "Switzerland",  # Chubb Limited is HQ'd in Zurich - a real, deliberate
                                                # person-location vs company-HQ-location mismatch
        "total_years_experience": 23,
        "headline": (
            "Strategic Data & AI Executive | GenAI & Agentic AI | Strategy & Governance | "
            "Enterprise Transformation | Ex-Microsoft | Advising BFSI on AI-Readiness"
        ),
        "linkedin_url": "",
        "email": "",
        "phone": "",
        "apollo_id": "621b7a87dbb6de00015e21ac",
        "employment_history": [
            {"company": "Chubb", "title": "VP / Head of Data, Chubb Overseas General Insurance CECI - APAC/EMEA/LATAM",
             "industry": "Insurance", "start": "2024-10", "end": "present"},
            {"company": "PepsiCo", "title": "CIO / Head of Data Analytics, AI & Digital - AMESA/APAC",
             "industry": "Food & Beverage", "start": "2023-08", "end": "2024-05"},
            {"company": "Microsoft", "title": "Director Software Engineering - Cloud + AI",
             "industry": "Technology", "start": "2020-07", "end": "2023-08"},
            {"company": "JPMorgan Chase & Co.", "title": "Vice President of Software Engineering",
             "industry": "Banking", "start": "2018-10", "end": "2020-07"},
            {"company": "Bank of America", "title": "VP of Technology",
             "industry": "Banking", "start": "2017-11", "end": "2018-10"},
            {"company": "Aon Hewitt", "title": "Leader - Delivery and Technology",
             "industry": "Financial Services", "start": "2008-12", "end": "2017-11"},
            {"company": "Fidelity Investments", "title": "Solutions Project Lead",
             "industry": "Financial Services", "start": "2003-10", "end": "2008-10"},
        ],
        "source_note": "apollo_live_direct_name_lookup_2026-09-19",
    })

    # Append the synthetic, non-BFSI records (see disclaimer at top of file).
    for row in OTHER_VERTICAL_ROWS:
        leads.append({
            "full_name": row["full_name"],
            "current_title": row["current_title"],
            "current_company": row["current_company"],
            "current_industry": row["current_industry"],
            "location": row["location"],
            "company_hq_location": row.get("company_hq_location", ""),
            "total_years_experience": row["total_years_experience"],
            "headline": row["headline"],
            "linkedin_url": "",
            "email": "",
            "phone": "",
            "apollo_id": "",
            "employment_history": row["employment_history"],
            "source_note": "synthetic_demo_example (not a real person - illustrates cross-vertical genericity only)",
        })

    out_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                             "app", "fixtures", "demo_leads.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(leads, f, indent=2)
    print(f"Wrote {len(leads)} demo leads to {out_path}")


if __name__ == "__main__":
    build()
