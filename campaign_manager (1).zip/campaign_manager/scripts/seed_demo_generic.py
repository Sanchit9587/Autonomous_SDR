"""
Proves the ICP engine is genuinely generic, not BFSI-specific.

Creates two SaaS-vertical campaigns against the SAME fixture data (which
now also contains a few synthetic non-BFSI records - see the disclaimer
in generate_demo_fixture.py) and the SAME scoring.py code - zero code
changes from the BFSI campaigns. Demonstrates, on a different industry:

  - a clean current-title match getting auto-qualified (Jordan Ellery)
  - the current-vs-historical-title split again (Priya Nandakumar is the
    SaaS-world equivalent of the Shalu Chadha case: rejected under
    current_only, qualified under current_or_historical)
  - the person-location hard gate rejecting an otherwise perfect match
    (Felix Adeyemi - right title/seniority/industry, wrong country)
  - wrong-industry noise correctly filtered out even for a genuinely
    senior person in their own field (Dana Whitcombe, Marcus Webb)

Run AFTER starting the API server and regenerating the fixture:
    python scripts/generate_demo_fixture.py
    uvicorn app.main:app --reload --port 8000      (separate terminal)
    python scripts/seed_demo_generic.py
"""
import os
import requests

BASE = os.getenv("API_BASE_URL", "http://localhost:8000")


def create_campaign(payload):
    r = requests.post(f"{BASE}/campaigns", json=payload, timeout=30)
    r.raise_for_status()
    return r.json()


def find_leads(campaign_id):
    r = requests.post(f"{BASE}/campaigns/{campaign_id}/find-leads", timeout=60)
    r.raise_for_status()
    return r.json()


def show(results, names):
    for n in names:
        row = next((r for r in results if r["lead"]["full_name"] == n), None)
        if row:
            print(f"  {n} -> score={row['score']}, stage={row['stage']}")
            print(f"    {row['explanation']}")
        else:
            print(f"  {n} -> not found in results")


def main():
    campaign_c = create_campaign({
        "name": "SaaS VP Engineering - US",
        "description": "Strict current-role ICP: active VP of Engineering at a SaaS company, based in the US.",
        "icp_filter": {
            "role_titles": ["VP of Engineering", "VP Engineering", "Head of Engineering"],
            "seniority": ["vp"],
            "min_years_experience": 10,
            "industry_tags": ["SaaS", "Software"],
            "person_location": ["USA"],
            "company_location": [],
            "title_match_mode": "current_only",
            "signal_tags": [],
            "reference_profiles": [],
        },
        "enabled_channels": ["email"],
    })
    print(f"Created campaign C: {campaign_c['id']} - {campaign_c['name']}")

    campaign_d = create_campaign({
        "name": "SaaS Ex-VP Engineering & Advisors - US",
        "description": "Wider ICP: held a VP-Engineering-level role in SaaS in the last 5 years, even if now in a different role (advisors, product leaders who came up through engineering).",
        "icp_filter": {
            "role_titles": ["VP of Engineering", "VP Engineering", "Head of Engineering"],
            "seniority": ["vp"],
            "min_years_experience": 10,
            "industry_tags": ["SaaS", "Software"],
            "person_location": ["USA"],
            "company_location": [],
            "title_match_mode": "current_or_historical",
            "historical_lookback_years": 5,
            "signal_tags": ["advisor"],
            "reference_profiles": [
                "Former VP of Engineering now advising SaaS founders on product and platform strategy",
            ],
        },
        "enabled_channels": ["email"],
    })
    print(f"Created campaign D: {campaign_d['id']} - {campaign_d['name']}")

    watch = ["Jordan Ellery", "Priya Nandakumar", "Marcus Webb", "Felix Adeyemi", "Dana Whitcombe"]

    print("\nRunning find-leads on campaign C (strict, current-only)...")
    results_c = find_leads(campaign_c["id"])
    print(f"  {len(results_c)} leads scored.")
    show(results_c, watch)

    print("\nRunning find-leads on campaign D (current-or-historical + signal tags)...")
    results_d = find_leads(campaign_d["id"])
    print(f"  {len(results_d)} leads scored.")
    show(results_d, watch)

    print("\nDone. Open the control panel and switch to these two campaigns to browse visually:")
    print("  streamlit run control_panel.py")


if __name__ == "__main__":
    main()
