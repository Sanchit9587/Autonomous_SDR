"""
Turns a plain-English ICP description into the structured ICPFilter schema
(app/schemas.py) - the "Job A: Parse" half of the intelligence layer
("Job B: Score" is scoring.py). Works for ANY vertical: the parser has no
BFSI-specific logic, only a small general-purpose vocabulary of titles,
seniority words, industries, and phrasing patterns.

Two parse paths:
  - deterministic (always available, zero API keys) - rule/keyword based,
    good enough for the kind of ICP sentence a sales/RevOps person
    actually writes ("BFSI CIOs in India, 15+ years, current or former").
  - LLM-assisted (if ANTHROPIC_API_KEY is set) - asks Claude to fill the
    exact same schema for phrasing the rules can't cover, with the
    deterministic result as a safety-net fallback if the call fails or
    returns something unparseable. Never silently returns an empty filter.

Either path also returns a plain-English "interpretation" string - the
model/parser stating out loud how it read the prompt, e.g. "I'm reading
'BFSI' as Banking + Financial Services + Insurance; person-location=India
with company location left open so MNC India heads qualify too." This is
what makes the parse auditable instead of a black box.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from app.config import settings
from app.schemas import ICPFilter

# --- Vocabulary (generic - extend freely for new verticals) --------------

TITLE_SYNONYMS: dict[str, list[str]] = {
    "CIO": ["cio", "chief information officer"],
    "CDO": ["cdo", "chief digital officer", "chief data officer"],
    "CTO": ["cto", "chief technology officer"],
    "CEO": ["ceo", "chief executive officer"],
    "CFO": ["cfo", "chief financial officer"],
    "COO": ["coo", "chief operating officer"],
    "CISO": ["ciso", "chief information security officer"],
    "VP of Engineering": ["vp engineering", "vp of engineering", "vice president of engineering", "vp eng"],
    "VP of Sales": ["vp sales", "vp of sales", "vice president of sales"],
    "VP of Product": ["vp product", "vp of product", "vice president of product"],
    "Head of Engineering": ["head of engineering"],
    "Head of Data": ["head of data"],
    "Chief Medical Information Officer": ["cmio", "chief medical information officer"],
}

INDUSTRY_GROUPS: dict[str, list[str]] = {
    # a single user-facing term can expand into several real industry tags
    "bfsi": ["Banking", "Financial Services", "Insurance"],
    "banking": ["Banking"],
    "insurance": ["Insurance"],
    "nbfc": ["Financial Services"],
    "fintech": ["Financial Services", "Software"],
    "financial services": ["Financial Services"],
    "saas": ["SaaS", "Software"],
    "software": ["Software"],
    "tech": ["Software", "Technology"],
    "healthcare": ["Healthcare"],
    "retail": ["Retail"],
    "manufacturing": ["Manufacturing"],
}

SENIORITY_KEYWORDS: dict[str, str] = {
    "c-suite": "c_suite", "c suite": "c_suite", "chief": "c_suite", "csuite": "c_suite",
    "vp": "vp", "vice president": "vp",
    "director": "director",
    "manager": "manager",
}

HISTORICAL_SIGNAL_WORDS = [
    "ex-", "ex ", "former", "formerly", "previously", "used to be", "used to hold",
    "past", "advisor", "advising", "board member", "retired",
]

# Small gazetteer - extend as needed. Order matters: longer/more specific
# strings first so "United States" isn't shadowed by a shorter partial match.
LOCATION_GAZETTEER = [
    "United States", "USA", "US", "United Kingdom", "UK", "India", "Canada",
    "Australia", "Singapore", "Germany", "France", "UAE", "United Arab Emirates",
    "Mumbai", "Bengaluru", "Bangalore", "Delhi", "New Delhi", "Chennai", "Hyderabad",
    "San Francisco", "New York", "Austin", "London", "Toronto",
]


@dataclass
class ParseResult:
    icp_filter: ICPFilter
    interpretation: str
    method: str  # "deterministic" | "llm"


def _find_years_experience(text: str) -> float:
    m = re.search(r"(\d+)\s*\+?\s*(?:years|yrs|yoe)", text, re.IGNORECASE)
    return float(m.group(1)) if m else 0.0


def _find_titles(text: str) -> list[str]:
    """Matches title synonyms, tolerating plurals ('CIOs', 'CDOs and CTOs')
    and simple comma/'and'-separated lists."""
    hits = []
    low = text.lower()
    for canonical, synonyms in TITLE_SYNONYMS.items():
        if any(re.search(rf"\b{re.escape(s)}s?\b", low) for s in synonyms):
            hits.append(canonical)
    return hits


def _find_industries(text: str) -> list[str]:
    low = text.lower()
    tags: list[str] = []
    for key, expansion in INDUSTRY_GROUPS.items():
        if key in low:
            for t in expansion:
                if t not in tags:
                    tags.append(t)
    return tags


def _find_seniority(text: str) -> list[str]:
    low = text.lower()
    tiers = []
    for key, tier in SENIORITY_KEYWORDS.items():
        if key in low and tier not in tiers:
            tiers.append(tier)
    return tiers


def _find_locations(text: str) -> list[str]:
    hits = []
    for loc in LOCATION_GAZETTEER:
        if re.search(rf"\b{re.escape(loc)}\b", text, re.IGNORECASE):
            canon = {"US": "United States", "USA": "United States", "UK": "United Kingdom",
                     "Bangalore": "Bengaluru", "New Delhi": "Delhi"}.get(loc, loc)
            if canon not in hits:
                hits.append(canon)
    return hits


def _wants_historical(text: str) -> bool:
    low = text.lower()
    return any(w in low for w in HISTORICAL_SIGNAL_WORDS)


def _extract_signal_tags(text: str) -> list[str]:
    low = text.lower()
    tags = []
    if re.search(r"advis", low):        # catches advisor/advising/advise/advisory
        tags.append("advis")
    if "board member" in low or "board seat" in low:
        tags.append("board member")
    if re.search(r"consult", low):      # catches consultant/consulting
        tags.append("consult")
    return tags


def _company_hq_flexible(text: str) -> bool:
    """True if the prompt explicitly says company HQ shouldn't matter."""
    low = text.lower()
    return any(p in low for p in [
        "regardless of", "even if their company", "even if the company",
        "no matter where the company", "company hq doesn't matter", "wherever the company",
    ])


def parse_deterministic(prompt: str) -> ParseResult:
    titles = _find_titles(prompt)
    industries = _find_industries(prompt)
    seniority = _find_seniority(prompt)
    locations = _find_locations(prompt)
    min_yoe = _find_years_experience(prompt)
    historical = _wants_historical(prompt)
    signal_tags = _extract_signal_tags(prompt)

    # If nothing explicit about seniority was said but a C-level title was
    # found, infer c_suite; same idea for VP-family titles.
    if not seniority and titles:
        if any(t in ("CIO", "CDO", "CTO", "CEO", "CFO", "COO", "CISO", "Chief Medical Information Officer") for t in titles):
            seniority.append("c_suite")
        if any("VP" in t for t in titles):
            seniority.append("vp")

    icp = ICPFilter(
        role_titles=titles,
        seniority=seniority,
        min_years_experience=min_yoe,
        industry_tags=industries,
        person_location=locations,
        company_location=[],  # always left open unless the caller edits it - see interpretation
        title_match_mode="current_or_historical" if historical else "current_only",
        historical_lookback_years=5,
        signal_tags=signal_tags,
        reference_profiles=[],
    )

    bits = []
    bits.append(f"Titles: {', '.join(titles) if titles else '(none detected - showing everyone regardless of title)'}")
    if seniority:
        bits.append(f"Seniority inferred: {', '.join(seniority)}")
    if min_yoe:
        bits.append(f"Experience floor: {min_yoe:.0f}+ years")
    if industries:
        bits.append(f"Industry tags: {', '.join(industries)}")
    if locations:
        bits.append(f"Person location: {', '.join(locations)} (company HQ left open - a person based here at a global company still qualifies)")
    else:
        bits.append("No location restriction detected - matching anywhere")
    if historical:
        bits.append(f"Detected 'former/ex-/advisor' language -> matching CURRENT OR PAST roles (lookback: 5 years), signal keywords: {signal_tags or '(none)'}")
    else:
        bits.append("No historical/ex-leader language detected -> matching CURRENT role only")

    interpretation = "Parsed this ICP as follows:\n- " + "\n- ".join(bits)
    return ParseResult(icp_filter=icp, interpretation=interpretation, method="deterministic")


def parse_with_llm(prompt: str) -> ParseResult:
    """Best-effort LLM parse; ALWAYS falls back to the deterministic parser
    on any error so a missing/invalid key never breaks the feature."""
    fallback = parse_deterministic(prompt)
    if not settings.anthropic_api_key:
        return fallback
    try:
        import anthropic
        import json as _json

        client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
        schema_hint = {
            "role_titles": ["list of job titles, e.g. CIO, VP of Engineering"],
            "seniority": ["c_suite | vp | director | manager"],
            "min_years_experience": "number",
            "industry_tags": ["list of industries"],
            "person_location": ["where the HUMAN is based - separate from company HQ"],
            "company_location": ["where the employer is HQ'd - leave [] if not restricted"],
            "title_match_mode": "current_only | current_or_historical",
            "historical_lookback_years": "number, only relevant if current_or_historical",
            "signal_tags": ["free-text bio/headline keywords, e.g. advisor, board member"],
        }
        msg = client.messages.create(
            model="claude-sonnet-5",
            max_tokens=500,
            messages=[{
                "role": "user",
                "content": (
                    "Extract a lead-targeting ICP filter from this sales campaign description. "
                    "Return ONLY valid JSON matching this shape (no prose, no markdown fences): "
                    f"{_json.dumps(schema_hint)}\n\n"
                    "Rules: person_location is where the PERSON lives, NOT the company's HQ - "
                    "these are independent; leave company_location empty unless the prompt "
                    "explicitly restricts where the EMPLOYER is headquartered. Use "
                    "'current_or_historical' only if the prompt mentions former/ex-/advisor/"
                    "board-member type language.\n\n"
                    f"Campaign description: {prompt}"
                ),
            }],
        )
        text = "".join(b.text for b in msg.content if hasattr(b, "text")).strip()
        text = re.sub(r"^```json\s*|\s*```$", "", text.strip())
        data = _json.loads(text)
        icp = ICPFilter(**{**fallback.icp_filter.model_dump(), **data})
        interpretation = "Parsed by Claude from your description:\n" + _json.dumps(data, indent=2)
        return ParseResult(icp_filter=icp, interpretation=interpretation, method="llm")
    except Exception as e:
        fallback.interpretation += f"\n\n(LLM parse was attempted but failed ({e}); showing the rule-based parse instead.)"
        return fallback


def parse_icp_prompt(prompt: str) -> ParseResult:
    if settings.anthropic_api_key:
        return parse_with_llm(prompt)
    return parse_deterministic(prompt)
