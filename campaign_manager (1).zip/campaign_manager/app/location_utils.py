"""
Shared location-matching helper.

Real-world location strings are inconsistent ("USA" vs "United States" vs
"US"; "Bangalore" vs "Bengaluru"). Both the ICP parser (which canonicalizes
what it detects, e.g. always writing "United States") and raw lead data
from Apollo (which might say "USA") need to agree on what counts as a
match, or a correctly-parsed filter could wrongly fail the location gate
against correctly-sourced data. This is the single source of truth both
app/scoring.py and app/icp_parser.py import, so they can't drift apart.
"""

ALIAS_GROUPS: list[list[str]] = [
    ["usa", "us", "united states", "united states of america", "america"],
    ["uk", "united kingdom", "britain", "great britain"],
    ["uae", "united arab emirates"],
    ["bengaluru", "bangalore"],
    ["delhi", "new delhi"],
    ["mumbai", "bombay"],
]


def location_matches(allowed: str, actual: str) -> bool:
    """True if `allowed` (a filter value, e.g. 'United States') should be
    considered satisfied by `actual` (a lead's raw location string, e.g.
    'Austin, TX, USA'), accounting for common aliases in either direction."""
    a = (allowed or "").lower().strip()
    b = (actual or "").lower()
    if not a:
        return True
    if a in b:
        return True
    for group in ALIAS_GROUPS:
        if a in group and any(alias in b for alias in group):
            return True
    return False
