from typing import Optional, List, Any
from pydantic import BaseModel, Field


class ICPFilter(BaseModel):
    """The generalized ICP schema - fill this out for ANY vertical, not just BFSI."""

    role_titles: List[str] = Field(default_factory=list, description="e.g. ['CIO','CDO','CTO']")
    seniority: List[str] = Field(default_factory=list, description="e.g. ['c_suite','vp']")
    min_years_experience: float = 0
    industry_tags: List[str] = Field(default_factory=list, description="e.g. ['Banking','Insurance']")

    person_location: List[str] = Field(default_factory=list, description="where the HUMAN sits")
    company_location: List[str] = Field(default_factory=list, description="where the employer HQ sits - leave empty for 'anywhere'")

    company_size_min: Optional[int] = None
    company_size_max: Optional[int] = None

    exclusions: List[str] = Field(default_factory=list, description="domains / companies / names to never contact")

    # Historical matching - this is what the Shalu Chadha test proved we need.
    title_match_mode: str = Field(default="current_only", description="'current_only' or 'current_or_historical'")
    historical_lookback_years: float = 5

    # Free-text signal keywords matched against headline/bio (advisor, board member, etc.)
    signal_tags: List[str] = Field(default_factory=list)

    # Golden examples: names/LinkedIn URLs of people you already know are a great fit.
    reference_profiles: List[str] = Field(default_factory=list)


class ScoringWeights(BaseModel):
    current_title_exact: float = 30
    historical_title_within_lookback: float = 18
    seniority_match: float = 15
    yoe_meets_floor: float = 15
    industry_match: float = 15
    signal_tag_match: float = 10
    reference_similarity_max: float = 15
    auto_qualify_threshold: float = 70
    review_min_threshold: float = 40


class CampaignCreate(BaseModel):
    name: str
    description: str = ""
    icp_filter: ICPFilter = Field(default_factory=ICPFilter)
    scoring_weights: ScoringWeights = Field(default_factory=ScoringWeights)
    enabled_channels: List[str] = Field(default_factory=lambda: ["email"])
    daily_send_limit: int = 50


class CampaignUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    icp_filter: Optional[ICPFilter] = None
    scoring_weights: Optional[ScoringWeights] = None
    enabled_channels: Optional[List[str]] = None
    daily_send_limit: Optional[int] = None


class CampaignOut(BaseModel):
    id: str
    name: str
    description: str
    status: str
    icp_filter: dict
    scoring_weights: dict
    enabled_channels: list
    daily_send_limit: int

    class Config:
        from_attributes = True


class EmploymentRecord(BaseModel):
    company: str
    title: str
    industry: str = ""
    start: str = ""
    end: str = ""  # "" or "present" for current role


class LeadIn(BaseModel):
    full_name: str
    current_title: str = ""
    current_company: str = ""
    current_industry: str = ""
    location: str = ""
    company_hq_location: str = ""
    total_years_experience: float = 0
    headline: str = ""
    linkedin_url: str = ""
    email: str = ""
    phone: str = ""
    apollo_id: str = ""
    employment_history: List[EmploymentRecord] = Field(default_factory=list)
    source_note: str = ""


class LeadOut(BaseModel):
    id: str
    full_name: str
    current_title: str
    current_company: str
    current_industry: str
    location: str
    company_hq_location: str = ""
    total_years_experience: float
    headline: str
    linkedin_url: str
    email: str
    phone: str
    employment_history: list

    class Config:
        from_attributes = True


class ScoreOut(BaseModel):
    lead: LeadOut
    score: float
    stage: str
    breakdown: dict
    explanation: str
    location_gate_passed: bool


class ICPPromptRequest(BaseModel):
    prompt: str


class ICPParseResponse(BaseModel):
    icp_filter: dict
    interpretation: str
    method: str


class CampaignFromPromptRequest(BaseModel):
    name: str
    description: str = ""
    prompt: str
    enabled_channels: List[str] = Field(default_factory=lambda: ["email"])
    daily_send_limit: int = 50


class OutreachRequest(BaseModel):
    lead_id: str
    campaign_id: str
    channel: str
    subject: Optional[str] = None
    content: Optional[str] = None
    prompt_version_id: Optional[str] = None


class AnalyticsSummary(BaseModel):
    campaign_id: str
    total_leads: int
    auto_qualified: int
    in_review: int
    rejected: int
    contacted: int
    responded: int
    meetings_booked: int
    by_channel: dict
    funnel: dict
