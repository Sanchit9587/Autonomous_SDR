"""
FastAPI backend - the orchestration layer.

This is the thing a DronaHQ agent's "Connector"/"Code" tool calls into
(via REST) to run an ICP search, get scored leads, and log outreach; it's
also directly usable by a human campaign manager through the Streamlit
control panel (control_panel.py) or this API's own /docs Swagger UI.

Run:  uvicorn app.main:app --reload --port 8000
"""
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import get_db, init_db
from app import models, schemas
from app.scoring import score_lead
from app.explain import explain
from app.apollo_client import search_people, match_person, ApolloError
from app.channels import get_channel_adapter
from app.icp_parser import parse_icp_prompt

app = FastAPI(title="Campaign Manager - Orchestration Backend", version="0.1.0")


@app.on_event("startup")
def _startup():
    init_db()


# ---------------------------------------------------------------------------
# Campaigns
# ---------------------------------------------------------------------------
@app.post("/campaigns", response_model=schemas.CampaignOut)
def create_campaign(payload: schemas.CampaignCreate, db: Session = Depends(get_db)):
    c = models.Campaign(
        name=payload.name,
        description=payload.description,
        icp_filter=payload.icp_filter.model_dump(),
        scoring_weights=payload.scoring_weights.model_dump(),
        enabled_channels=payload.enabled_channels,
        daily_send_limit=payload.daily_send_limit,
        status=models.CampaignStatus.draft,
    )
    db.add(c)
    db.commit()
    db.refresh(c)
    # Seed prompt-version 1 for each enabled channel's "agent" so every
    # future action can point at a specific instruction version.
    for agent_name in ["icp_fitment", "personalization", "conversation"]:
        db.add(models.PromptVersion(
            campaign_id=c.id, agent_name=agent_name, version=1,
            instruction_text=f"(default v1 instruction for {agent_name} - edit via PUT /campaigns/{{id}}/prompts)",
        ))
    db.commit()
    return c


@app.get("/campaigns", response_model=list[schemas.CampaignOut])
def list_campaigns(db: Session = Depends(get_db)):
    return db.query(models.Campaign).order_by(models.Campaign.created_at.desc()).all()


@app.get("/campaigns/{campaign_id}", response_model=schemas.CampaignOut)
def get_campaign(campaign_id: str, db: Session = Depends(get_db)):
    c = db.get(models.Campaign, campaign_id)
    if not c:
        raise HTTPException(404, "Campaign not found")
    return c


@app.put("/campaigns/{campaign_id}", response_model=schemas.CampaignOut)
def update_campaign(campaign_id: str, payload: schemas.CampaignUpdate, db: Session = Depends(get_db)):
    c = db.get(models.Campaign, campaign_id)
    if not c:
        raise HTTPException(404, "Campaign not found")
    data = payload.model_dump(exclude_unset=True)
    if "icp_filter" in data and data["icp_filter"] is not None:
        c.icp_filter = data.pop("icp_filter")
    if "scoring_weights" in data and data["scoring_weights"] is not None:
        c.scoring_weights = data.pop("scoring_weights")
    for k, v in data.items():
        if v is not None:
            setattr(c, k, v)
    c.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(c)
    return c


@app.post("/campaigns/{campaign_id}/pause", response_model=schemas.CampaignOut)
def pause_campaign(campaign_id: str, db: Session = Depends(get_db)):
    """The 'kill switch' - pause one campaign without touching any other
    campaign's agents, leads, or in-flight sequences."""
    c = db.get(models.Campaign, campaign_id)
    if not c:
        raise HTTPException(404, "Campaign not found")
    c.status = models.CampaignStatus.paused
    db.commit()
    return c


@app.post("/campaigns/{campaign_id}/resume", response_model=schemas.CampaignOut)
def resume_campaign(campaign_id: str, db: Session = Depends(get_db)):
    c = db.get(models.Campaign, campaign_id)
    if not c:
        raise HTTPException(404, "Campaign not found")
    c.status = models.CampaignStatus.active
    db.commit()
    return c


# ---------------------------------------------------------------------------
# Plain-English ICP parsing - "give it a prompt instead of filters"
# ---------------------------------------------------------------------------
@app.post("/icp/parse", response_model=schemas.ICPParseResponse)
def parse_icp(payload: schemas.ICPPromptRequest):
    """Preview-only: turns a plain-English ICP description into the
    structured filter, with an explanation of how it was read - without
    creating a campaign. Works for ANY vertical, not just BFSI."""
    result = parse_icp_prompt(payload.prompt)
    return schemas.ICPParseResponse(
        icp_filter=result.icp_filter.model_dump(),
        interpretation=result.interpretation,
        method=result.method,
    )


@app.post("/campaigns/from-prompt")
def create_campaign_from_prompt(payload: schemas.CampaignFromPromptRequest, db: Session = Depends(get_db)):
    """Parses the prompt into an ICPFilter and creates the campaign in one
    call. The parsed filter is stored as-is on the campaign, so it can
    still be edited afterwards via PUT /campaigns/{id} like any other."""
    result = parse_icp_prompt(payload.prompt)
    c = models.Campaign(
        name=payload.name,
        description=payload.description or f"Created from prompt: \"{payload.prompt}\"",
        icp_filter=result.icp_filter.model_dump(),
        scoring_weights=schemas.ScoringWeights().model_dump(),
        enabled_channels=payload.enabled_channels,
        daily_send_limit=payload.daily_send_limit,
        status=models.CampaignStatus.draft,
    )
    db.add(c)
    db.commit()
    db.refresh(c)
    for agent_name in ["icp_fitment", "personalization", "conversation"]:
        db.add(models.PromptVersion(
            campaign_id=c.id, agent_name=agent_name, version=1,
            instruction_text=f"(default v1 instruction for {agent_name})",
        ))
    db.commit()
    return {"campaign": schemas.CampaignOut.model_validate(c).model_dump(), "interpretation": result.interpretation, "parse_method": result.method}


# ---------------------------------------------------------------------------
# Lead sourcing + scoring ("ICP Builder" intelligence layer)
# ---------------------------------------------------------------------------
@app.post("/campaigns/{campaign_id}/find-leads", response_model=list[schemas.ScoreOut])
def find_leads(campaign_id: str, limit: int = 200, db: Session = Depends(get_db)):
    """Runs the campaign's ICP filter against Apollo, upserts leads, scores
    every one of them against THIS campaign's weights/ICP, and persists
    both the Lead and its LeadScore. Safe to re-run - existing leads are
    matched by name+company rather than duplicated."""
    c = db.get(models.Campaign, campaign_id)
    if not c:
        raise HTTPException(404, "Campaign not found")

    icp = schemas.ICPFilter(**c.icp_filter)
    weights = schemas.ScoringWeights(**c.scoring_weights)

    try:
        raw_leads = search_people(icp, limit=limit)
    except ApolloError as e:
        raise HTTPException(502, str(e))

    reference_corpus = icp.reference_profiles or None

    results = []
    for raw in raw_leads:
        lead = (
            db.query(models.Lead)
            .filter(models.Lead.full_name == raw["full_name"], models.Lead.current_company == raw.get("current_company", ""))
            .first()
        )
        if not lead:
            lead = models.Lead(
                full_name=raw["full_name"],
                current_title=raw.get("current_title", ""),
                current_company=raw.get("current_company", ""),
                current_industry=raw.get("current_industry", ""),
                location=raw.get("location", ""),
                company_hq_location=raw.get("company_hq_location", ""),
                total_years_experience=raw.get("total_years_experience", 0),
                headline=raw.get("headline", ""),
                linkedin_url=raw.get("linkedin_url", ""),
                email=raw.get("email", ""),
                phone=raw.get("phone", ""),
                apollo_id=raw.get("apollo_id", ""),
                employment_history=raw.get("employment_history", []),
                source_note=raw.get("source_note", ""),
            )
            db.add(lead)
            db.flush()

        result = score_lead(lead, icp, weights, reference_corpus=reference_corpus)
        explanation = explain(lead, result)

        score_row = models.LeadScore(
            lead_id=lead.id,
            campaign_id=c.id,
            score=result.score,
            stage=models.LeadStage(result.stage),
            breakdown=result.breakdown,
            explanation=explanation,
            location_gate_passed=result.location_gate_passed,
        )
        db.add(score_row)
        results.append(schemas.ScoreOut(
            lead=schemas.LeadOut.model_validate(lead),
            score=result.score,
            stage=result.stage,
            breakdown=result.breakdown,
            explanation=explanation,
            location_gate_passed=result.location_gate_passed,
        ))

    db.commit()
    results.sort(key=lambda r: r.score, reverse=True)
    return results


@app.get("/campaigns/{campaign_id}/leads", response_model=list[schemas.ScoreOut])
def list_scored_leads(campaign_id: str, stage: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(models.LeadScore).filter(models.LeadScore.campaign_id == campaign_id)
    if stage:
        q = q.filter(models.LeadScore.stage == stage)
    rows = q.order_by(models.LeadScore.score.desc()).all()
    out = []
    for r in rows:
        out.append(schemas.ScoreOut(
            lead=schemas.LeadOut.model_validate(r.lead),
            score=r.score,
            stage=r.stage.value,
            breakdown=r.breakdown,
            explanation=r.explanation,
            location_gate_passed=r.location_gate_passed,
        ))
    return out


@app.post("/leads/{lead_id}/stage")
def set_lead_stage(lead_id: str, campaign_id: str, stage: str, db: Session = Depends(get_db)):
    """Manual override - a human reviewer approving/rejecting an in_review lead."""
    row = (
        db.query(models.LeadScore)
        .filter(models.LeadScore.lead_id == lead_id, models.LeadScore.campaign_id == campaign_id)
        .order_by(models.LeadScore.created_at.desc())
        .first()
    )
    if not row:
        raise HTTPException(404, "No score found for this lead+campaign")
    try:
        row.stage = models.LeadStage(stage)
    except ValueError:
        raise HTTPException(400, f"Invalid stage '{stage}'")
    db.commit()
    return {"ok": True, "lead_id": lead_id, "stage": stage}


@app.post("/coverage-check")
def coverage_check(name: str, organization_name: Optional[str] = None):
    """Direct name(+company) lookup - the right tool for 'is this specific
    person in our data universe at all', independent of any ICP filter."""
    try:
        person = match_person(name, organization_name)
    except ApolloError as e:
        raise HTTPException(502, str(e))
    if not person:
        return {"found": False, "name": name}
    return {"found": True, "person": person}


# ---------------------------------------------------------------------------
# Outreach + CRM logging
# ---------------------------------------------------------------------------
@app.post("/outreach/send")
def send_outreach(payload: schemas.OutreachRequest, db: Session = Depends(get_db)):
    lead = db.get(models.Lead, payload.lead_id)
    campaign = db.get(models.Campaign, payload.campaign_id)
    if not lead or not campaign:
        raise HTTPException(404, "Lead or campaign not found")
    if campaign.status == models.CampaignStatus.paused:
        raise HTTPException(409, "Campaign is paused - resume it before sending outreach")

    adapter = get_channel_adapter(payload.channel)
    result = adapter.send(lead, payload.subject or "", payload.content or "")

    interaction = models.Interaction(
        lead_id=lead.id,
        campaign_id=campaign.id,
        prompt_version_id=payload.prompt_version_id or "",
        channel=models.Channel(payload.channel),
        direction=models.InteractionDirection.outbound,
        subject=payload.subject or "",
        content=payload.content or "",
        status=result.status,
        provider=result.provider,
        provider_ref=result.provider_ref,
        meta=result.meta,
    )
    db.add(interaction)

    # Move the lead's latest score row to "contacted" on a successful/dry-run send.
    latest = (
        db.query(models.LeadScore)
        .filter(models.LeadScore.lead_id == lead.id, models.LeadScore.campaign_id == campaign.id)
        .order_by(models.LeadScore.created_at.desc())
        .first()
    )
    if latest and result.status in ("sent", "dry_run"):
        latest.stage = models.LeadStage.contacted

    db.commit()
    return {"status": result.status, "provider": result.provider, "provider_ref": result.provider_ref, "meta": result.meta}


@app.post("/webhooks/dronahq-voice")
def dronahq_voice_webhook(payload: dict, db: Session = Depends(get_db)):
    """Where a DronaHQ voice Campaign posts a call result back, so it lands
    in the same Interaction (CRM) table as every other channel."""
    lead_id = payload.get("lead_id")
    campaign_id = payload.get("campaign_id")
    if not lead_id or not campaign_id:
        raise HTTPException(400, "lead_id and campaign_id are required")

    interaction = models.Interaction(
        lead_id=lead_id,
        campaign_id=campaign_id,
        channel=models.Channel.voice,
        direction=models.InteractionDirection.inbound,
        status=payload.get("status", "delivered"),
        provider="dronahq_voice",
        provider_ref=payload.get("call_id", ""),
        content=payload.get("transcript", ""),
        meta=payload,
    )
    db.add(interaction)
    db.commit()
    return {"ok": True}


@app.get("/campaigns/{campaign_id}/interactions")
def list_interactions(campaign_id: str, db: Session = Depends(get_db)):
    rows = (
        db.query(models.Interaction)
        .filter(models.Interaction.campaign_id == campaign_id)
        .order_by(models.Interaction.created_at.desc())
        .all()
    )
    return [
        {
            "id": r.id, "lead_id": r.lead_id, "channel": r.channel.value, "direction": r.direction.value,
            "status": r.status, "provider": r.provider, "created_at": r.created_at.isoformat(),
            "subject": r.subject, "content": r.content, "meta": r.meta,
        }
        for r in rows
    ]


# ---------------------------------------------------------------------------
# Analytics layer
# ---------------------------------------------------------------------------
@app.get("/campaigns/{campaign_id}/analytics", response_model=schemas.AnalyticsSummary)
def campaign_analytics(campaign_id: str, db: Session = Depends(get_db)):
    scores = db.query(models.LeadScore).filter(models.LeadScore.campaign_id == campaign_id).all()
    interactions = db.query(models.Interaction).filter(models.Interaction.campaign_id == campaign_id).all()

    def count_stage(stage):
        return sum(1 for s in scores if s.stage.value == stage)

    by_channel: dict = {}
    for i in interactions:
        by_channel.setdefault(i.channel.value, {"sent": 0, "dry_run": 0, "failed": 0})
        by_channel[i.channel.value][i.status] = by_channel[i.channel.value].get(i.status, 0) + 1

    total = len(scores)
    funnel = {
        "sourced": total,
        "qualified": count_stage("qualified"),
        "in_review": count_stage("in_review"),
        "contacted": count_stage("contacted"),
        "responded": count_stage("responded"),
        "meeting_booked": count_stage("meeting_booked"),
    }

    return schemas.AnalyticsSummary(
        campaign_id=campaign_id,
        total_leads=total,
        auto_qualified=count_stage("qualified"),
        in_review=count_stage("in_review"),
        rejected=count_stage("rejected"),
        contacted=count_stage("contacted"),
        responded=count_stage("responded"),
        meetings_booked=count_stage("meeting_booked"),
        by_channel=by_channel,
        funnel=funnel,
    )


@app.get("/health")
def health():
    return {"ok": True}
