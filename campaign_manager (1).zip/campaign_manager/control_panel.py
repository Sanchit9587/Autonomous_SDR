"""
Campaign Manager - Control Panel

A working UI for a person running a campaign: create a campaign with an
ICP filter in plain fields, run lead-sourcing + scoring, review each lead's
explained score, approve/reject, queue outreach, and watch analytics.

This is a standalone Streamlit app that talks to the FastAPI backend over
HTTP - the same API surface a DronaHQ agent ("Connector"/"Code" tool) would
call. In the DronaHQ-hosted version of this product, this screen is what
gets rebuilt in DronaHQ's Apps Studio (Vibe Coding) pointed at the same
backend; this file is the fastest way to run and demo the whole pipeline
today without that separate DronaHQ setup.

Run:
    uvicorn app.main:app --reload --port 8000     # in one terminal
    streamlit run control_panel.py                 # in another
"""
import os
import requests
import pandas as pd
import streamlit as st

BASE = os.getenv("API_BASE_URL", "http://localhost:8000")

st.set_page_config(page_title="Campaign Manager", layout="wide")
st.title("AI SDR - Campaign Manager")


def api_get(path, **params):
    r = requests.get(f"{BASE}{path}", params=params, timeout=30)
    r.raise_for_status()
    return r.json()


def api_post(path, json=None, **params):
    r = requests.post(f"{BASE}{path}", json=json, params=params, timeout=60)
    r.raise_for_status()
    return r.json()


def api_put(path, json=None):
    r = requests.put(f"{BASE}{path}", json=json, timeout=30)
    r.raise_for_status()
    return r.json()


# ---------------------------------------------------------------------------
# Sidebar: campaign picker + create-new form
# ---------------------------------------------------------------------------
st.sidebar.header("Campaigns")

try:
    campaigns = api_get("/campaigns")
except requests.exceptions.ConnectionError:
    st.error(f"Can't reach the backend at {BASE}. Start it with:\n\nuvicorn app.main:app --reload --port 8000")
    st.stop()

campaign_names = {c["name"]: c for c in campaigns}
selected_name = st.sidebar.selectbox("Select a campaign", ["+ New campaign"] + list(campaign_names.keys()))

if selected_name == "+ New campaign":
    creation_mode = st.sidebar.radio("How do you want to define the ICP?", ["Describe it in plain English", "Structured filters"])

    if creation_mode == "Describe it in plain English":
        st.subheader("Create a campaign from a plain-English description")
        st.caption(
            "Works for any vertical - BFSI, SaaS, healthcare, retail, anything. Mentions of "
            "'former/ex-/advisor/board member' automatically switch on current-or-historical "
            "title matching, the same mechanism that correctly separates a still-active exec "
            "from someone who has since moved to a different role."
        )
        prompt = st.text_area(
            "Describe who you're targeting",
            "Find BFSI CIOs, CDOs and CTOs in India, senior leaders with at least 15 years of "
            "experience. Include people based in India even if their company is headquartered "
            "elsewhere.",
            height=120,
        )
        col_a, col_b = st.columns(2)
        with col_a:
            preview_clicked = st.button("Preview parsed ICP")
        with col_b:
            campaign_name = st.text_input("Campaign name (needed to create)", "")

        if preview_clicked or "last_parse" in st.session_state:
            if preview_clicked:
                parsed = api_post("/icp/parse", json={"prompt": prompt})
                st.session_state["last_parse"] = parsed
            parsed = st.session_state["last_parse"]
            st.markdown("**How this was interpreted:**")
            st.text(parsed["interpretation"])
            st.markdown("**Resulting filter (editable as JSON before creating, if needed):**")
            st.json(parsed["icp_filter"])

        if st.button("Create campaign from this prompt", type="primary", disabled=not campaign_name):
            created = api_post("/campaigns/from-prompt", json={
                "name": campaign_name, "prompt": prompt, "enabled_channels": ["email", "linkedin"],
            })
            st.success(f"Created '{created['campaign']['name']}'.")
            st.text(created["interpretation"])
            del st.session_state["last_parse"]
            st.rerun()
        st.stop()

    st.sidebar.subheader("New campaign - ICP filter")
    with st.sidebar.form("new_campaign"):
        name = st.text_input("Campaign name", "BFSI Tech Leaders - India")
        description = st.text_area("Description", "")

        role_titles = st.text_input("Target titles (comma-separated)", "CIO, CDO, CTO")
        seniority = st.multiselect("Seniority", ["c_suite", "vp", "director", "manager"], default=["c_suite"])
        min_yoe = st.number_input("Minimum years of experience", 0, 40, 15)
        industry_tags = st.text_input("Industry tags (comma-separated)", "Banking, Financial Services, Insurance")

        st.caption("Person location = where the HUMAN sits. Company location = where the employer is HQ'd. "
                   "Leave company location blank to include people at global companies working out of your target region.")
        person_location = st.text_input("Person location (comma-separated)", "India")
        company_location = st.text_input("Company HQ location (comma-separated, optional)", "")

        title_match_mode = st.radio(
            "Title matching",
            ["current_only", "current_or_historical"],
            help="'current_or_historical' also matches people who HELD a target title in the past "
                 "N years - catches advisors/ex-leaders a current-title-only filter would miss.",
        )
        lookback_years = st.number_input("Historical lookback (years)", 1, 15, 5,
                                          disabled=(title_match_mode == "current_only"))
        signal_tags = st.text_input("Signal keywords in bio/headline (comma-separated, optional)", "")
        reference_profiles = st.text_area(
            "Reference / 'golden example' profiles (one per line, optional)",
            help="Describe 1-10 people you already know are a great fit, in plain text. New leads are "
                 "scored partly on similarity to these - no training data needed.",
        )
        enabled_channels = st.multiselect("Enabled channels", ["email", "sms", "voice", "linkedin"], default=["email", "linkedin"])
        daily_send_limit = st.number_input("Daily send limit", 1, 1000, 50)

        submitted = st.form_submit_button("Create campaign")
        if submitted:
            payload = {
                "name": name,
                "description": description,
                "icp_filter": {
                    "role_titles": [t.strip() for t in role_titles.split(",") if t.strip()],
                    "seniority": seniority,
                    "min_years_experience": min_yoe,
                    "industry_tags": [t.strip() for t in industry_tags.split(",") if t.strip()],
                    "person_location": [t.strip() for t in person_location.split(",") if t.strip()],
                    "company_location": [t.strip() for t in company_location.split(",") if t.strip()],
                    "title_match_mode": title_match_mode,
                    "historical_lookback_years": lookback_years,
                    "signal_tags": [t.strip() for t in signal_tags.split(",") if t.strip()],
                    "reference_profiles": [l.strip() for l in reference_profiles.splitlines() if l.strip()],
                },
                "scoring_weights": {},
                "enabled_channels": enabled_channels,
                "daily_send_limit": daily_send_limit,
            }
            new_campaign = api_post("/campaigns", json=payload)
            st.sidebar.success(f"Created '{new_campaign['name']}'. Select it above.")
            st.rerun()
    st.info("Fill out the ICP filter on the left and create your first campaign, "
            "or run `python scripts/seed_demo.py` to load two ready-made example campaigns.")
    st.stop()

campaign = campaign_names[selected_name]
campaign_id = campaign["id"]

# ---------------------------------------------------------------------------
# Campaign header + controls
# ---------------------------------------------------------------------------
col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
with col1:
    st.subheader(campaign["name"])
    st.caption(campaign.get("description", ""))
with col2:
    st.metric("Status", campaign["status"])
with col3:
    if campaign["status"] == "paused":
        if st.button("Resume campaign", type="primary"):
            api_post(f"/campaigns/{campaign_id}/resume")
            st.rerun()
    else:
        if st.button("Pause campaign", type="secondary"):
            api_post(f"/campaigns/{campaign_id}/pause")
            st.rerun()
with col4:
    if st.button("Run lead search", type="primary"):
        with st.spinner("Querying Apollo + scoring every lead against this campaign's ICP..."):
            api_post(f"/campaigns/{campaign_id}/find-leads")
        st.success("Done.")
        st.rerun()

with st.expander("ICP filter for this campaign"):
    st.json(campaign["icp_filter"])

tab_leads, tab_outreach, tab_analytics, tab_crm = st.tabs(
    ["Scored Leads", "Outreach", "Analytics", "CRM Log"]
)

# ---------------------------------------------------------------------------
# Scored leads tab
# ---------------------------------------------------------------------------
with tab_leads:
    leads = api_get(f"/campaigns/{campaign_id}/leads")
    if not leads:
        st.info("No leads scored yet - click 'Run lead search' above.")
    else:
        stage_filter = st.multiselect(
            "Filter by stage", ["qualified", "in_review", "rejected", "contacted", "responded", "meeting_booked"],
            default=["qualified", "in_review"],
        )
        filtered = [l for l in leads if l["stage"] in stage_filter] if stage_filter else leads

        rows = [{
            "Score": l["score"],
            "Stage": l["stage"],
            "Name": l["lead"]["full_name"],
            "Title": l["lead"]["current_title"],
            "Company": l["lead"]["current_company"],
            "Location": l["lead"]["location"],
            "Lead ID": l["lead"]["id"],
        } for l in filtered]
        df = pd.DataFrame(rows)
        st.dataframe(df.drop(columns=["Lead ID"]), use_container_width=True, height=320)

        st.markdown("#### Inspect a lead's score explanation")
        options = {f"{l['lead']['full_name']} ({l['score']:.0f}, {l['stage']})": l for l in filtered}
        if options:
            pick = st.selectbox("Choose a lead", list(options.keys()))
            l = options[pick]
            c1, c2 = st.columns([2, 1])
            with c1:
                st.markdown(f"**{l['lead']['full_name']}** — {l['lead']['current_title']} at {l['lead']['current_company']}")
                st.write(l["explanation"])
                st.markdown("**Score breakdown**")
                st.json(l["breakdown"])
                if l["lead"]["employment_history"]:
                    st.markdown("**Employment history**")
                    st.table(pd.DataFrame(l["lead"]["employment_history"]))
            with c2:
                st.metric("Fit score", f"{l['score']:.0f} / 100")
                st.write("Location gate:", "✅ passed" if l["location_gate_passed"] else "❌ failed")
                new_stage = st.selectbox("Override stage", ["qualified", "in_review", "rejected", "do_not_contact"],
                                          index=["qualified", "in_review", "rejected", "do_not_contact"].index(l["stage"]) if l["stage"] in ["qualified", "in_review", "rejected", "do_not_contact"] else 1)
                if st.button("Apply override"):
                    api_post(f"/leads/{l['lead']['id']}/stage", campaign_id=campaign_id, stage=new_stage)
                    st.success("Updated.")
                    st.rerun()

# ---------------------------------------------------------------------------
# Outreach tab
# ---------------------------------------------------------------------------
with tab_outreach:
    st.markdown("Send (or dry-run log) outreach to a qualified/in-review lead.")
    leads = api_get(f"/campaigns/{campaign_id}/leads")
    actionable = [l for l in leads if l["stage"] in ("qualified", "in_review")]
    if not actionable:
        st.info("No qualified or in-review leads yet.")
    else:
        options = {f"{l['lead']['full_name']} ({l['stage']})": l for l in actionable}
        pick = st.selectbox("Lead", list(options.keys()))
        l = options[pick]
        channel = st.selectbox("Channel", campaign["enabled_channels"] or ["email"])
        subject = st.text_input("Subject (email only)", f"Quick question for {l['lead']['full_name'].split()[0]}")
        content = st.text_area(
            "Message / call brief",
            f"Hi {l['lead']['full_name'].split()[0]}, reaching out because of your background as "
            f"{l['lead']['current_title']} at {l['lead']['current_company']}...",
            height=140,
        )
        if st.button("Send outreach", type="primary"):
            result = api_post("/outreach/send", json={
                "lead_id": l["lead"]["id"], "campaign_id": campaign_id,
                "channel": channel, "subject": subject, "content": content,
            })
            if result["status"] == "dry_run":
                st.warning(f"DRY RUN (no live provider configured) - logged to CRM. Details: {result['meta']}")
            elif result["status"] == "sent":
                st.success(f"Sent via {result['provider']} (ref: {result['provider_ref']})")
            else:
                st.error(f"Failed: {result['meta']}")

# ---------------------------------------------------------------------------
# Analytics tab
# ---------------------------------------------------------------------------
with tab_analytics:
    a = api_get(f"/campaigns/{campaign_id}/analytics")
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Total sourced", a["total_leads"])
    c2.metric("Auto-qualified", a["auto_qualified"])
    c3.metric("In review", a["in_review"])
    c4.metric("Contacted", a["contacted"])
    c5.metric("Meetings booked", a["meetings_booked"])

    st.markdown("#### Funnel")
    funnel_df = pd.DataFrame(list(a["funnel"].items()), columns=["Stage", "Count"])
    st.bar_chart(funnel_df.set_index("Stage"))

    if a["by_channel"]:
        st.markdown("#### Outreach by channel")
        rows = []
        for ch, counts in a["by_channel"].items():
            for status, n in counts.items():
                rows.append({"Channel": ch, "Status": status, "Count": n})
        st.dataframe(pd.DataFrame(rows), use_container_width=True)

# ---------------------------------------------------------------------------
# CRM log tab
# ---------------------------------------------------------------------------
with tab_crm:
    interactions = api_get(f"/campaigns/{campaign_id}/interactions")
    if not interactions:
        st.info("No interactions logged yet.")
    else:
        st.dataframe(pd.DataFrame(interactions), use_container_width=True, height=400)
